/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { OfficeAndTeamSection } from './components/OfficeAndTeamSection';
import { WhyChooseUs } from './components/WhyChooseUs';
import { Services } from './components/Services';
import { MountingStructuresSection } from './components/MountingStructuresSection';
import { RoiCalculator } from './components/RoiCalculator';
import { ProjectsGallery } from './components/ProjectsGallery';
import { Testimonials } from './components/Testimonials';
import { ContactSection } from './components/ContactSection';
import { FaqSection } from './components/FaqSection';
import { Footer } from './components/Footer';
import { FloatingActions } from './components/FloatingActions';
import { StandaloneCodeModal } from './components/StandaloneCodeModal';

export default function App() {
  const [isCodeModalOpen, setIsCodeModalOpen] = useState(false);
  const [selectedCalcDetails, setSelectedCalcDetails] = useState<{
    capacity: number;
    monthlyBill: number;
    currency: string;
  } | null>(null);

  const handleSelectSystemForQuote = (details: {
    capacity: number;
    monthlyBill: number;
    currency: string;
  }) => {
    setSelectedCalcDetails(details);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 antialiased selection:bg-amber-400 selection:text-slate-900 flex flex-col font-sans relative">
      {/* Fixed Ambient Light Orbs for Glassmorphism Translucency */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
        <div className="absolute -top-40 -left-40 w-[600px] h-[600px] bg-gradient-to-br from-amber-500/20 to-orange-600/10 rounded-full blur-[130px]" />
        <div className="absolute top-[20%] -right-40 w-[600px] h-[600px] bg-gradient-to-bl from-sky-500/20 to-blue-600/10 rounded-full blur-[140px]" />
        <div className="absolute top-[45%] -left-32 w-[650px] h-[650px] bg-gradient-to-tr from-purple-500/15 to-pink-600/10 rounded-full blur-[140px]" />
        <div className="absolute top-[70%] -right-20 w-[550px] h-[550px] bg-gradient-to-tl from-emerald-500/15 to-teal-600/10 rounded-full blur-[130px]" />
        <div className="absolute -bottom-40 left-1/3 w-[650px] h-[650px] bg-gradient-to-t from-amber-500/15 to-orange-500/10 rounded-full blur-[140px]" />
        {/* Subtle grid pattern resembling solar silicon cells on glass */}
        <div 
          className="absolute inset-0 opacity-[0.035] pointer-events-none" 
          style={{ backgroundImage: `radial-gradient(rgba(255, 255, 255, 0.4) 1px, transparent 1px)`, backgroundSize: '24px 24px' }} 
        />
      </div>

      <div className="relative z-10 flex flex-col min-h-screen">
        {/* 1. Header / Navigation Bar */}
        <Navbar onOpenCodeModal={() => setIsCodeModalOpen(true)} />

        {/* Main Content Sections */}
        <main className="flex-1">
        {/* 2. Hero Section */}
        <Hero />

        {/* 3. Bikaner Office & Team Showcase (Dinesh, Enterprise Manager, Mukta Prasad Colony) */}
        <OfficeAndTeamSection />

        {/* 4. Features / Why Choose Us */}
        <WhyChooseUs />

        {/* 5. Services & Solutions */}
        <Services />

        {/* 6. Premium Solar Mounting Structures (From User Posters) */}
        <MountingStructuresSection />

        {/* 7. Interactive Solar ROI / Savings Estimator */}
        <RoiCalculator onSelectSystemForQuote={handleSelectSystemForQuote} />

        {/* 8. Projects / Completed Installations Gallery */}
        <ProjectsGallery />

        {/* 9. Client Testimonials */}
        <Testimonials />

        {/* 10. Lead Generation & Google Form Integration */}
        <ContactSection
          prefilledCapacity={selectedCalcDetails?.capacity}
          prefilledBill={selectedCalcDetails?.monthlyBill}
        />

        {/* 11. FAQ Accordion Section */}
        <FaqSection />
      </main>

      {/* 12. Comprehensive Footer */}
      <Footer onOpenCodeModal={() => setIsCodeModalOpen(true)} />

      {/* 13. Floating Actions (WhatsApp & Call to 7852044655) */}
      <FloatingActions />

      {/* 14. Modal to Export/Copy Standalone single-file index.html */}
      <StandaloneCodeModal
        isOpen={isCodeModalOpen}
        onClose={() => setIsCodeModalOpen(false)}
      />
      </div>
    </div>
  );
}
