import React from 'react';
import { Award, Phone, Mail, MapPin, CheckCircle2, Shield, Wrench, RefreshCw, Zap, Sparkles } from 'lucide-react';
import { SolarLogo } from './SolarLogo';

interface SolarTeamPosterProps {
  className?: string;
  imageSrc?: string;
}

export const SolarTeamPoster: React.FC<SolarTeamPosterProps> = ({
  className = '',
  imageSrc,
}) => {
  return (
    <div
      className={`relative rounded-3xl overflow-hidden border border-slate-300 shadow-2xl bg-slate-950 text-white ${className}`}
    >
      {/* High-Fidelity Digital Replica of the official SOLAR TEAM Poster */}
      <div className="relative aspect-square w-full p-6 sm:p-8 flex flex-col justify-between bg-gradient-to-b from-slate-100 via-white to-slate-900 text-slate-900">
        
        {/* Header Bar */}
        <div className="flex items-start justify-between border-b border-slate-200 pb-4">
          <div className="flex items-center gap-3">
            <SolarLogo className="w-12 h-10" />
          </div>
          <div className="text-right">
            <span className="text-[10px] font-extrabold uppercase tracking-widest text-sky-800 bg-sky-100 px-2.5 py-1 rounded-full border border-sky-300 block">
              REGISTERED ENTERPRISE
            </span>
            <span className="text-xs font-bold text-slate-700 mt-1 block">
              Mukta Prasad Colony, Bikaner
            </span>
          </div>
        </div>

        {/* Middle Content */}
        <div className="grid grid-cols-12 gap-4 items-center my-auto py-4">
          
          {/* Left 4 Features */}
          <div className="col-span-5 space-y-2.5">
            <div className="flex items-center gap-2 p-2 rounded-xl bg-amber-50 border border-amber-200 text-xs">
              <Shield className="w-4 h-4 text-amber-600 shrink-0" />
              <div>
                <p className="font-extrabold text-slate-900 text-[11px] leading-tight">HIGH STRENGTH</p>
                <p className="text-[9px] text-slate-600">Engineered for maximum load</p>
              </div>
            </div>

            <div className="flex items-center gap-2 p-2 rounded-xl bg-sky-50 border border-sky-200 text-xs">
              <CheckCircle2 className="w-4 h-4 text-sky-600 shrink-0" />
              <div>
                <p className="font-extrabold text-slate-900 text-[11px] leading-tight">CORROSION RESISTANT</p>
                <p className="text-[9px] text-slate-600">Hot-dip galvanized for long life</p>
              </div>
            </div>

            <div className="flex items-center gap-2 p-2 rounded-xl bg-emerald-50 border border-emerald-200 text-xs">
              <Wrench className="w-4 h-4 text-emerald-600 shrink-0" />
              <div>
                <p className="font-extrabold text-slate-900 text-[11px] leading-tight">FAST INSTALLATION</p>
                <p className="text-[9px] text-slate-600">Hassle-free roof setup</p>
              </div>
            </div>

            <div className="flex items-center gap-2 p-2 rounded-xl bg-purple-50 border border-purple-200 text-xs">
              <Zap className="w-4 h-4 text-purple-600 shrink-0" />
              <div>
                <p className="font-extrabold text-slate-900 text-[11px] leading-tight">COMPATIBLE</p>
                <p className="text-[9px] text-slate-600">Suitable for all types of solar</p>
              </div>
            </div>
          </div>

          {/* Right Solar Rooftop Engineering & Enterprise Presentation */}
          <div className="col-span-7 relative pl-2">
            <div className="relative rounded-2xl overflow-hidden border border-slate-300 shadow-xl bg-slate-900 aspect-[4/3]">
              {/* Pure Solar Rooftop Installation */}
              <img
                src={imageSrc || "https://images.unsplash.com/photo-1509391365360-2e959784a276?auto=format&fit=crop&w=700&q=80"}
                alt="Solar Bright Technologies Bikaner Rooftop Solar Installation"
                className="w-full h-full object-cover"
                onError={(e) => {
                  (e.currentTarget as HTMLImageElement).src =
                    "data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 700 525' fill='%230f172a'><rect width='700' height='525'/><circle cx='350' cy='180' r='80' fill='%23f59e0b' opacity='0.7'/><polygon points='100,450 350,260 450,340 600,220 650,450' fill='%230284c7' opacity='0.5'/><text x='350' y='490' fill='%23f8fafc' font-size='20' font-weight='bold' text-anchor='middle' font-family='sans-serif'>SOLAR BRIGHT TECHNOLOGIES · BIKANER</text></svg>";
                }}
              />
              
              {/* Badge Overlay */}
              <div className="absolute bottom-2 left-2 right-2 p-2.5 bg-slate-950/90 backdrop-blur-md rounded-xl border border-amber-400/40 flex items-center justify-between text-white">
                <div>
                  <h5 className="text-xs font-black tracking-wide text-amber-400">DINESH SIR</h5>
                  <p className="text-[9px] font-bold text-slate-300 uppercase tracking-wider">
                    ENTERPRISE MANAGER · 7852044655
                  </p>
                  <p className="text-[8px] text-slate-400">Mukta Prasad Colony, Bikaner</p>
                </div>
                <span className="text-[8px] font-bold text-emerald-400 bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-500/40">
                  BIKANER ONLY
                </span>
              </div>
            </div>

            {/* Exclusive Bikaner Stamp */}
            <div className="mt-2 text-right">
              <span className="text-[10px] font-black text-amber-600 uppercase tracking-tight block">
                SERVICES PROVIDE PRESENT ONLY IN BIKANER
              </span>
            </div>
          </div>

        </div>

        {/* Bottom Trust & Contact Bar */}
        <div className="pt-3 border-t border-slate-800 text-slate-400 bg-slate-950 -mx-6 -mb-6 sm:-mx-8 sm:-mb-8 p-4 rounded-b-3xl">
          <div className="grid grid-cols-5 text-center text-[8px] font-bold text-slate-300 pb-2 border-b border-slate-800">
            <span>STRONG & DURABLE</span>
            <span>WEATHER RESISTANT</span>
            <span>LOW MAINTENANCE</span>
            <span>LONG TERM RELIABILITY</span>
            <span>BUILT FOR CLEAN FUTURE</span>
          </div>
          <div className="pt-2 flex flex-wrap items-center justify-between text-[10px] text-amber-400 font-bold px-1">
            <span>📞 +91 78520 44655</span>
            <span>✉️ solarbrighttechnologies@gmail.com</span>
            <span>📍 Bikaner, Rajasthan</span>
          </div>
        </div>

      </div>
    </div>
  );
};
