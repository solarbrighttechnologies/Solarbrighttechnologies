import React, { useState } from 'react';
import { X, Copy, Check, Download, FileCode, ExternalLink } from 'lucide-react';
import { STANDALONE_HTML_CODE } from '../data/standaloneHtmlCode';

interface StandaloneCodeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const StandaloneCodeModal: React.FC<StandaloneCodeModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const handleCopy = () => {
    navigator.clipboard.writeText(STANDALONE_HTML_CODE);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleDownload = () => {
    const blob = new Blob([STANDALONE_HTML_CODE], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'index.html';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/80 backdrop-blur-md animate-fadeIn">
      <div className="bg-slate-900/90 backdrop-blur-2xl text-slate-100 rounded-3xl max-w-4xl w-full max-h-[92vh] flex flex-col shadow-[0_8px_32px_0_rgba(0,0,0,0.6)] border border-white/15 overflow-hidden">
        
        {/* Modal Header */}
        <div className="p-6 border-b border-white/10 flex items-center justify-between bg-slate-950/80 backdrop-blur-md">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center">
              <FileCode className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white font-display">
                Standalone Single-File index.html
              </h3>
              <p className="text-xs text-slate-400">
                Self-contained HTML + embedded Tailwind CDN + Vanilla JS ready for Netlify / hosting
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            aria-label="Close code modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Action Bar */}
        <div className="px-6 py-3 bg-slate-900/60 border-b border-white/10 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2 text-slate-300">
            <span className="inline-block w-2 h-2 rounded-full bg-emerald-400" />
            <span>Production-ready single file (~45 KB)</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleCopy}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold transition-all"
            >
              {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
              <span>{copied ? 'Copied to Clipboard!' : 'Copy Code'}</span>
            </button>

            <button
              onClick={handleDownload}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-slate-700 hover:bg-slate-600 text-white font-semibold transition-all"
            >
              <Download className="w-4 h-4" />
              <span>Download index.html</span>
            </button>

            <a
              href="/standalone-index.html"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1 px-3 py-2 rounded-xl bg-slate-700/60 hover:bg-slate-700 text-slate-300 hover:text-white transition-all"
            >
              <span>Direct Link</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>
        </div>

        {/* Guide Callout */}
        <div className="px-6 py-3 bg-amber-950/40 border-b border-amber-500/20 text-xs text-amber-200/90 leading-relaxed">
          <p>
            📌 <strong>Customization Guide:</strong> Search in the code for{' '}
            <code className="bg-slate-800 text-amber-300 px-1.5 py-0.5 rounded font-mono">
              &lt;!-- REPLACE THIS WITH YOUR OWN IMAGE URL --&gt;
            </code>{' '}
            to swap photos, and{' '}
            <code className="bg-slate-800 text-amber-300 px-1.5 py-0.5 rounded font-mono">
              &lt;!-- PASTE YOUR GOOGLE FORM EMBED LINK HERE --&gt;
            </code>{' '}
            to drop your Google Form embed link!
          </p>
        </div>

        {/* Code Content Viewer */}
        <div className="flex-1 overflow-auto p-6 bg-slate-950 font-mono text-xs text-slate-300 leading-relaxed select-all">
          <pre>
            <code>{STANDALONE_HTML_CODE}</code>
          </pre>
        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-slate-950 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
          <span>Click "Copy Code" or "Download index.html" to deploy anywhere instantly.</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-750 text-slate-200 font-medium"
          >
            Close
          </button>
        </div>

      </div>
    </div>
  );
};
