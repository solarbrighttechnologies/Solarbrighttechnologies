import React, { useState } from 'react';
import { ChevronDown, HelpCircle } from 'lucide-react';

interface FaqItem {
  question: string;
  answer: string;
}

export const FaqSection: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const faqs: FaqItem[] = [
    {
      question: 'How does the Government PM Surya Ghar Subsidy work?',
      answer:
        'Under the central government’s PM Surya Ghar Muft Bijli Yojana, residential individual homeowners receive a Direct Benefit Transfer (DBT) into their bank account: ₹30,000 for 1 kW, ₹60,000 for 2 kW, and a maximum of ₹78,000 for systems of 3 kW capacity and above. Solar Bright Technologies registers your installation on the National Portal, liaisons with your electricity DISCOM, and ensures smooth subsidy disbursement directly into your bank account.',
    },
    {
      question: 'What is Net Metering and how does it slash my power bill by up to 100%?',
      answer:
        'A bidirectional Net Meter tracks both the electricity you pull from the utility grid and the excess solar electricity your rooftop panels export to the grid during sunny hours. At the end of the billing cycle, you are only billed for the net units consumed. If your solar system exports more energy than your home consumed, the excess units are rolled over as financial credits on your future electricity bills.',
    },
    {
      question: 'How much shadow-free rooftop space do I need?',
      answer:
        'As an industry standard, 1 kW of high-efficiency Mono PERC solar modules requires approximately 80 to 100 square feet of shadow-free rooftop area. For example, a 3 kW residential setup requires approximately 250 to 300 square feet. We also provide elevated, galvanized structures so you can retain 100% of your terrace recreation or sit-out area underneath.',
    },
    {
      question: 'Will my solar panels work during monsoon, rains, or winter overcast days?',
      answer:
        'Yes! Modern photovoltaic solar panels produce electricity using ambient diffused daylight, not merely blistering direct heat. On cloudy or rainy days, panels generate approximately 25% to 40% of their peak rated capacity. When solar production is lower, your home seamlessly draws any extra units needed from the utility grid without flicker or interruption.',
    },
    {
      question: 'What warranty and maintenance do you offer?',
      answer:
        'Every Solar Bright Technologies installation is backed by a 25-Year Linear Performance Warranty on Tier-1 solar modules (guaranteeing 80%+ efficiency at year 25), a 5-to-10 year replacement warranty on string inverters, and 5 Years of comprehensive free onsite maintenance, electrical health audits, and remote cloud IoT monitoring.',
    },
    {
      question: 'Can I finance my solar installation with low-interest EMI?',
      answer:
        'Yes! We partner with leading public and private banks offering collateral-free green solar loans under priority sector lending guidelines. Interest rates start as low as 7% p.a., with zero upfront down payment options. In most installations, your monthly reduction in electricity bills is greater than your loan EMI!',
    },
  ];

  const toggleFaq = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <section id="faqs" className="py-20 bg-slate-900/40 backdrop-blur-xl border-t border-white/10 text-white">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-xs font-bold uppercase tracking-widest text-amber-400">
            Got Questions?
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white mt-2 font-display">
            Frequently Asked Questions
          </h2>
          <p className="text-base text-slate-300 mt-4 leading-relaxed">
            Everything you need to know about rooftop solar installation, net metering, government subsidies, and warranty coverage.
          </p>
        </div>

        {/* Accordion Stack */}
        <div className="space-y-4">
          {faqs.map((faq, index) => {
            const isOpen = openIndex === index;
            return (
              <div
                key={index}
                className="bg-slate-900/60 hover:bg-slate-800/80 backdrop-blur-xl rounded-2xl border border-white/10 overflow-hidden shadow-lg transition-all duration-200"
              >
                <button
                  type="button"
                  onClick={() => toggleFaq(index)}
                  className="w-full px-6 py-5 text-left flex items-center justify-between font-bold text-white text-base focus:outline-none hover:text-amber-400 transition-colors"
                >
                  <span className="flex items-center gap-3 pr-4">
                    <HelpCircle className="w-5 h-5 text-amber-400 shrink-0" />
                    <span>{faq.question}</span>
                  </span>
                  <ChevronDown
                    className={`w-5 h-5 text-slate-400 shrink-0 transition-transform duration-200 ${
                      isOpen ? 'rotate-180 text-amber-400' : ''
                    }`}
                  />
                </button>

                {isOpen && (
                  <div className="px-6 pb-6 text-sm text-slate-300 leading-relaxed border-t border-white/10 pt-4">
                    {faq.answer}
                  </div>
                )}
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
