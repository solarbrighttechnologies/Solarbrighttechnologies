import React from 'react';
import { MapPin, Zap, CheckCircle2, Award } from 'lucide-react';
import residentialProjectImage from '../assets/images/regenerated_image_1792218426949.png';

export const ProjectsGallery: React.FC = () => {
  const featuredProjects = [
    {
      id: 1,
      title: 'Residential Rooftop Solar Installation',
      badge: '5 kW On-Grid Plant',
      location: 'Mukta Prasad Colony, Bikaner',
      generation: '~650 Units / Month',
      savings: '100% Electricity Bill Offset',
      image: residentialProjectImage,
      description:
        'Elevated rust-resistant galvanized structure with Tier-1 Mono PERC bi-facial panels. Retained 100% usable terrace space with net-metering and ₹78,000 PM Surya Ghar subsidy approval.',
      highlights: ['Tier-1 Mono PERC Modules', 'Heavy GI Elevated Frame', '₹78,000 Subsidy Credited'],
    },
    {
      id: 2,
      title: 'Commercial & Industrial Solar Plant',
      badge: '50 kW Industrial Array',
      location: 'Industrial Area, Bikaner',
      generation: '~6,400 Units / Month',
      savings: '₹48,000+ Monthly Savings',
      image: 'https://images.unsplash.com/photo-1613665813446-82a78c468a1d?auto=format&fit=crop&w=1000&q=80',
      description:
        'Custom non-penetrating rooftop clamps engineered for high wind tolerance. Multi-MPPT inverter configuration with live digital telemetry and 40% accelerated depreciation tax benefit.',
      highlights: ['Non-Penetrating Clamps', '40% Accelerated Depreciation', 'Live Cloud Monitoring'],
    },
  ];

  return (
    <section id="projects" className="py-20 bg-slate-900/40 backdrop-blur-xl border-y border-white/10 text-white relative overflow-hidden">
      {/* Background glow */}
      <div className="absolute top-1/2 left-1/4 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-amber-500/20 text-amber-400 border border-amber-500/30 rounded-full text-xs font-bold mb-3">
            <Award className="w-3.5 h-3.5" />
            <span>PROVEN EXCELLENCE IN BIKANER</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white mt-1 font-display">
            Featured Solar Installations
          </h2>
          <p className="text-base text-slate-300 mt-4 leading-relaxed">
            Take a look at actual on-ground rooftop installations engineered and commissioned in Bikaner by Solar Bright Technologies.
          </p>
        </div>

        {/* 2 Featured Installation Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
          {featuredProjects.map((project) => (
            <div
              key={project.id}
              className="bg-slate-900/60 hover:bg-slate-800/80 backdrop-blur-xl rounded-3xl overflow-hidden border border-white/10 hover:border-amber-400/60 transition-all duration-300 shadow-2xl group flex flex-col justify-between"
            >
              {/* Image Container */}
              <div className="relative aspect-[16/10] overflow-hidden bg-slate-950">
                <img
                  src={project.image}
                  alt={project.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                  onError={(e) => {
                    (e.currentTarget as HTMLImageElement).src =
                      "data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 800 500' fill='%230f172a'><rect width='800' height='500'/><circle cx='400' cy='180' r='60' fill='%23f59e0b' opacity='0.6'/><polygon points='100,420 300,280 450,360 650,240 700,420' fill='%230284c7' opacity='0.4'/></svg>";
                  }}
                />
                <div className="absolute top-4 left-4">
                  <span className="px-3.5 py-1.5 rounded-full text-xs font-bold bg-amber-500 text-slate-950 shadow-md">
                    {project.badge}
                  </span>
                </div>
                <div className="absolute bottom-4 left-4 right-4 bg-slate-950/80 backdrop-blur-md p-3 rounded-2xl border border-white/10 flex items-center justify-between text-xs">
                  <span className="flex items-center gap-1.5 text-slate-300">
                    <MapPin className="w-3.5 h-3.5 text-amber-400" />
                    <span>{project.location}</span>
                  </span>
                  <span className="flex items-center gap-1.5 text-emerald-400 font-bold">
                    <Zap className="w-3.5 h-3.5" />
                    <span>{project.generation}</span>
                  </span>
                </div>
              </div>

              {/* Card Details */}
              <div className="p-6 sm:p-8 space-y-4 flex-1 flex flex-col justify-between">
                <div>
                  <h3 className="text-xl sm:text-2xl font-bold font-display text-white">
                    {project.title}
                  </h3>
                  <p className="text-xs sm:text-sm text-slate-300 mt-2 leading-relaxed">
                    {project.description}
                  </p>
                </div>

                <div className="pt-4 border-t border-slate-700/80 space-y-3">
                  <div className="flex flex-wrap gap-2 text-xs">
                    {project.highlights.map((h, i) => (
                      <span
                        key={i}
                        className="inline-flex items-center gap-1.5 px-3 py-1 bg-slate-700/60 text-slate-200 rounded-lg border border-slate-600 font-medium"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5 text-amber-400" />
                        <span>{h}</span>
                      </span>
                    ))}
                  </div>

                  <div className="flex items-center justify-between pt-2 text-xs">
                    <span className="text-slate-400">Verified Impact:</span>
                    <span className="text-emerald-400 font-extrabold">{project.savings}</span>
                  </div>
                </div>
              </div>

            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
