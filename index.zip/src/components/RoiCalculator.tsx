import React, { useState, useId } from 'react';
import { ArrowRight, TreePine, Building2, Home } from 'lucide-react';

interface RoiCalculatorProps {
  onSelectSystemForQuote?: (details: { capacity: number; monthlyBill: number; currency: string }) => void;
}

export const RoiCalculator: React.FC<RoiCalculatorProps> = ({ onSelectSystemForQuote }) => {
  const [customerType, setCustomerType] = useState<'residential' | 'commercial'>('residential');
  const [monthlyBill, setMonthlyBill] = useState<number>(4500);
  const billInputId = useId();
  const billSliderId = useId();

  // Financial & engineering calculation models strictly in Indian Rupees (₹ INR) for Bikaner
  // For India residential: ~₹7.5/unit average. 1 kW produces ~120-130 units/mo (~₹950/mo offset).
  const unitCostFactor = 950;
  const rawCapacity = monthlyBill / unitCostFactor;
  // Round to nearest 0.5 kW
  const capacityKW = Math.min(100, Math.max(1, Math.round(rawCapacity * 2) / 2));

  // Savings
  const monthlySavings = Math.round(monthlyBill * 0.95);
  const annualSavings = monthlySavings * 12;

  // Roof space: approx 90 sq ft per kW for modern Mono PERC
  const roofAreaSqFt = Math.round(capacityKW * 90);

  // Government PM Surya Ghar Subsidy (India Residential)
  // 1 kW: ₹30,000 | 2 kW: ₹60,000 | >= 3 kW: ₹78,000 max
  let subsidyAmount = 0;
  if (customerType === 'residential') {
    if (capacityKW <= 1) subsidyAmount = 30000;
    else if (capacityKW <= 2) subsidyAmount = 60000;
    else subsidyAmount = 78000;
  } else {
    // Commercial has accelerated depreciation 40%
    subsidyAmount = Math.round(capacityKW * 55000 * 0.25);
  }

  // Gross cost estimation
  const costPerKW = 65000;
  const grossCost = capacityKW * costPerKW;
  const netInvestment = Math.max(15000, grossCost - subsidyAmount);

  // Payback period
  const paybackYears = (netInvestment / Math.max(annualSavings, 1000)).toFixed(1);

  // 25-Year Lifetime Savings (accounting for tariff inflation)
  const lifetimeSavingsFormatted = `₹${((annualSavings * 25 * 1.15) / 100000).toFixed(1)} Lakhs`;

  // Environmental impact: ~1.25 tons CO2 per kW/yr; 1 tree absorbs ~20kg CO2/yr -> ~16 trees per kW
  const treesPlanted = Math.round(capacityKW * 16);
  const co2OffsetTons = (capacityKW * 1.25).toFixed(1);

  // Quick preset buttons (in ₹ INR)
  const quickBills = [2500, 4500, 8000, 15000, 30000];

  const handleApplyToQuote = () => {
    if (onSelectSystemForQuote) {
      onSelectSystemForQuote({ capacity: capacityKW, monthlyBill, currency: 'INR' });
    }
    const contactElem = document.getElementById('contact');
    if (contactElem) {
      contactElem.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="calculator" className="py-20 bg-slate-900/40 backdrop-blur-xl text-white relative overflow-hidden border-y border-white/10">
      {/* Background ambient lighting */}
      <div className="absolute -top-32 -right-32 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-32 -left-32 w-96 h-96 bg-orange-500/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-xs font-bold uppercase tracking-widest text-amber-400">
            Interactive Financial Tool · Bikaner
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white mt-2 font-display">
            Solar ROI & Monthly Savings Estimator
          </h2>
          <p className="text-base text-slate-300 mt-4 leading-relaxed">
            Discover exactly how much rooftop solar can reduce your power bills. Get instant plant sizing, PM Surya Ghar subsidy estimation, and payback timeline.
          </p>
        </div>

        {/* Main Calculator Box */}
        <div className="max-w-4xl mx-auto bg-slate-900/70 backdrop-blur-2xl rounded-3xl p-6 sm:p-10 border border-white/10 shadow-[0_8px_32px_0_rgba(0,0,0,0.5)]">
          
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            
            {/* Input Controls (Left Column) */}
            <div className="lg:col-span-6 space-y-6">
              
              {/* Customer Type Selector & Currency Badge */}
              <div className="flex flex-wrap items-center justify-between gap-3">
                {/* Customer Type Selector */}
                <div className="flex items-center gap-1 bg-slate-900/90 p-1 rounded-xl border border-slate-700">
                  <button
                    type="button"
                    onClick={() => setCustomerType('residential')}
                    className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-lg transition-all ${
                      customerType === 'residential'
                        ? 'bg-amber-500 text-slate-950 shadow-sm'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    <Home className="w-3.5 h-3.5" />
                    <span>Home Rooftop</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setCustomerType('commercial')}
                    className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-lg transition-all ${
                      customerType === 'commercial'
                        ? 'bg-amber-500 text-slate-950 shadow-sm'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    <Building2 className="w-3.5 h-3.5" />
                    <span>Commercial / Industrial</span>
                  </button>
                </div>

                {/* Fixed INR Currency Indicator */}
                <span className="text-xs font-bold text-amber-400 bg-amber-500/10 px-3 py-1.5 rounded-lg border border-amber-500/30">
                  ₹ INR (Rajasthan)
                </span>
              </div>

              {/* Direct Bill Input Box */}
              <div>
                <label htmlFor={billInputId} className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">
                  Average Monthly Electricity Bill
                </label>
                <div className="flex items-center gap-3 bg-slate-900/90 p-4 rounded-2xl border border-slate-700 focus-within:border-amber-400 transition-colors">
                  <span className="text-3xl font-extrabold text-amber-400 tabular-nums">
                    ₹
                  </span>
                  <input
                    id={billInputId}
                    type="number"
                    value={monthlyBill}
                    onChange={(e) => setMonthlyBill(Math.max(0, Number(e.target.value)))}
                    min={500}
                    max={200000}
                    step={100}
                    className="w-full bg-transparent text-3xl font-extrabold text-white focus:outline-none tabular-nums font-mono"
                  />
                  <span className="text-xs text-slate-400 font-semibold uppercase tracking-wider shrink-0">
                    / Month
                  </span>
                </div>
              </div>

              {/* Range Slider */}
              <div className="space-y-2">
                <label htmlFor={billSliderId} className="sr-only">Adjust Monthly Electricity Bill</label>
                <input
                  id={billSliderId}
                  type="range"
                  min={1000}
                  max={40000}
                  step={250}
                  value={monthlyBill}
                  onChange={(e) => setMonthlyBill(Number(e.target.value))}
                  className="w-full h-2.5 bg-slate-700 rounded-lg appearance-none cursor-pointer"
                />
                <div className="flex justify-between text-[11px] text-slate-400 font-mono">
                  <span>₹1,000</span>
                  <span>₹20,000</span>
                  <span>₹40,000+</span>
                </div>
              </div>

              {/* Quick Select Buttons */}
              <div className="space-y-2">
                <span className="text-xs text-slate-400 block font-medium">Quick Select Average Bill:</span>
                <div className="flex flex-wrap gap-2">
                  {quickBills.map((val) => (
                    <button
                      key={val}
                      type="button"
                      onClick={() => setMonthlyBill(val)}
                      className={`py-1.5 px-3 text-xs font-semibold rounded-lg border transition-all ${
                        monthlyBill === val
                          ? 'bg-amber-500 text-slate-950 border-amber-400 font-bold'
                          : 'bg-slate-700/60 hover:bg-slate-700 text-slate-200 border-slate-600'
                      }`}
                    >
                      ₹{val.toLocaleString('en-IN')}
                    </button>
                  ))}
                </div>
              </div>

              <p className="text-[11px] text-slate-400 italic">
                *Calculated using 5.2 peak sun-hours/day for Bikaner and the latest PM Surya Ghar Muft Bijli Yojana Central DBT guidelines.
              </p>
            </div>

            {/* Dynamic Results Card (Right Column) */}
            <div className="lg:col-span-6 bg-gradient-to-br from-slate-900 to-slate-950 p-6 sm:p-8 rounded-2xl border border-amber-500/30 space-y-6">
              
              {/* Marquee System Spec */}
              <div className="flex items-center justify-between border-b border-slate-800 pb-4">
                <div>
                  <span className="text-xs uppercase tracking-wider text-amber-400 font-bold">
                    Recommended System
                  </span>
                  <div className="text-3xl font-extrabold text-white mt-0.5 font-display">
                    <span>{capacityKW.toFixed(1)}</span>{' '}
                    <span className="text-lg font-medium text-amber-400">kW Plant</span>
                  </div>
                </div>
                <div className="text-right">
                  <span className="text-xs uppercase tracking-wider text-slate-400 font-medium">
                    Roof Area Required
                  </span>
                  <p className="text-lg font-bold text-slate-200 mt-0.5 tabular-nums">
                    {roofAreaSqFt} sq.ft
                  </p>
                </div>
              </div>

              {/* Financial Metrics 4-Box Grid */}
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-slate-800/60 p-4 rounded-xl border border-slate-700/60">
                  <span className="text-xs text-slate-400 block mb-1">Est. Monthly Savings</span>
                  <span className="text-xl sm:text-2xl font-bold text-emerald-400 tabular-nums">
                    ₹{monthlySavings.toLocaleString('en-IN')}
                  </span>
                </div>
                <div className="bg-slate-800/60 p-4 rounded-xl border border-slate-700/60">
                  <span className="text-xs text-slate-400 block mb-1">Est. Annual Savings</span>
                  <span className="text-xl sm:text-2xl font-bold text-emerald-400 tabular-nums">
                    ₹{annualSavings.toLocaleString('en-IN')}
                  </span>
                </div>
                <div className="bg-slate-800/60 p-4 rounded-xl border border-slate-700/60">
                  <span className="text-xs text-slate-400 block mb-1">
                    {customerType === 'residential' ? 'PM Subsidy (Max DBT)' : 'Depreciation Shield'}
                  </span>
                  <span className="text-xl sm:text-2xl font-bold text-amber-400 tabular-nums">
                    ₹{subsidyAmount.toLocaleString('en-IN')}
                  </span>
                </div>
                <div className="bg-slate-800/60 p-4 rounded-xl border border-slate-700/60">
                  <span className="text-xs text-slate-400 block mb-1">Est. Payback Period</span>
                  <span className="text-xl sm:text-2xl font-bold text-sky-400 tabular-nums">
                    {paybackYears} Yrs
                  </span>
                </div>
              </div>

              {/* 25-Year Lifetime Savings & Environmental Proof */}
              <div className="bg-amber-500/10 border border-amber-500/25 p-3.5 rounded-xl space-y-2">
                <div className="flex items-center justify-between text-xs text-amber-300">
                  <span className="font-medium">25-Yr Lifetime Net Savings:</span>
                  <span className="text-sm font-extrabold text-white tabular-nums">
                    {lifetimeSavingsFormatted}
                  </span>
                </div>
                <div className="flex items-center justify-between text-[11px] text-emerald-400 border-t border-amber-500/10 pt-2">
                  <span className="flex items-center gap-1.5">
                    <TreePine className="w-3.5 h-3.5" />
                    <span>Offset: {co2OffsetTons} Tons CO₂ / Yr</span>
                  </span>
                  <span className="font-semibold">Equivalent to {treesPlanted} Trees</span>
                </div>
              </div>

              {/* Pre-fill CTA */}
              <button
                type="button"
                onClick={handleApplyToQuote}
                className="w-full flex items-center justify-center gap-2 py-3.5 px-6 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-sm shadow-lg shadow-amber-500/20 transition-all hover:scale-[1.01]"
              >
                <span>Get Solar Quotation From Dinesh Sir ({capacityKW.toFixed(1)} kW)</span>
                <ArrowRight className="w-4 h-4" />
              </button>

            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
