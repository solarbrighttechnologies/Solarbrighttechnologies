import React from 'react';
import { ExternalLink, Sparkles, MapPin, Star, Award } from 'lucide-react';
import googleProfileQrPng from '../assets/images/google_profile_qr.png';
import googleProfileQrSvg from '../assets/images/google_profile_qr.svg';
import instagramQrPng from '../assets/images/solarbrighttechnologies_qr.png';
import instagramQrSvg from '../assets/images/solarbrighttechnologies_qr.svg';

interface InstagramQrCardProps {
  className?: string;
  variant?: 'footer' | 'compact' | 'featured';
}

export const InstagramQrCard: React.FC<InstagramQrCardProps> = ({
  className = '',
}) => {
  const instagramUrl = 'https://www.instagram.com/solarbrighttechnologies/';
  const googleProfileUrl = 'https://www.google.com/search?q=Solar+Bright+Technologies+Bikaner+Mukta+Prasad+Colony';

  return (
    <div className={`space-y-6 ${className}`}>
      
      {/* 2-Column Grid: Google Business Profile QR + Official Instagram QR */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">

        {/* 1. Google Business Profile QR Card */}
        <div className="relative group rounded-3xl p-5 sm:p-6 bg-gradient-to-br from-slate-900/80 via-sky-950/40 to-slate-900/90 backdrop-blur-2xl border border-sky-500/30 shadow-[0_8px_32px_0_rgba(0,0,0,0.5)] transition-all duration-300 hover:border-sky-400 hover:shadow-sky-500/20 text-white">
          {/* Subtle Ambient Glow */}
          <div className="absolute -top-10 -right-10 w-32 h-32 bg-sky-500/15 rounded-full blur-2xl pointer-events-none group-hover:scale-125 transition-transform duration-500" />

          <div className="relative z-10 flex flex-col sm:flex-row items-center gap-5">
            {/* Google Profile QR Container */}
            <a
              href={googleProfileUrl}
              target="_blank"
              rel="noopener noreferrer"
              title="Scan or Tap to Open Google Profile for Solar Bright Technologies Bikaner"
              className="relative block shrink-0 bg-white p-3 rounded-2xl shadow-lg border-2 border-sky-400/50 hover:border-sky-400 transition-all duration-300 hover:scale-105 group/qr text-center"
            >
              <div className="relative w-32 h-32 sm:w-36 sm:h-36 mx-auto flex items-center justify-center bg-white rounded-xl overflow-hidden">
                <img
                  src={googleProfileQrPng}
                  alt="Solar Bright Technologies Bikaner Google Profile QR Code"
                  className="w-full h-full object-contain"
                  onError={(e) => {
                    const target = e.currentTarget;
                    if (target.src !== googleProfileQrSvg) {
                      target.src = googleProfileQrSvg;
                    }
                  }}
                />
                {/* Google Multi-Color 'G' Logo Overlay in Center */}
                <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                  <div className="w-8 h-8 rounded-full bg-white p-1 shadow-md flex items-center justify-center border border-slate-200">
                    <svg viewBox="0 0 24 24" className="w-6 h-6">
                      <path
                        fill="#4285F4"
                        d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                      />
                      <path
                        fill="#34A853"
                        d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                      />
                      <path
                        fill="#FBBC05"
                        d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                      />
                      <path
                        fill="#EA4335"
                        d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                      />
                    </svg>
                  </div>
                </div>
              </div>

              <p className="mt-2 text-[10px] font-black tracking-wider text-slate-950 uppercase font-sans">
                GOOGLE PROFILE
              </p>
              <span className="text-[9px] text-sky-600 font-bold block">Scan or Tap to Open</span>
            </a>

            {/* Google Profile Details */}
            <div className="space-y-2.5 text-center sm:text-left flex-1">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-sky-500/20 border border-sky-400/30 rounded-full text-[11px] font-bold text-sky-300">
                <Star className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
                <span>Google Business Profile</span>
              </div>

              <div>
                <h4 className="text-lg font-black text-white tracking-tight font-display">
                  Solar Bright Technologies
                </h4>
                <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                  Scan this QR code with your smartphone camera to find our official Google profile, verified ratings, photos, and navigation to our Mukta Prasad Colony office.
                </p>
              </div>

              <div className="pt-1 flex flex-wrap items-center justify-center sm:justify-start gap-2">
                <a
                  href={googleProfileUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs shadow-md transition-all duration-200 hover:-translate-y-0.5"
                >
                  <MapPin className="w-3.5 h-3.5" />
                  <span>View Google Profile</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
                <span className="text-[11px] text-sky-200 font-medium">
                  Bikaner, Rajasthan
                </span>
              </div>
            </div>

          </div>
        </div>

        {/* 2. Official Instagram Profile QR Card */}
        <div className="relative group rounded-3xl p-5 sm:p-6 bg-gradient-to-br from-slate-900/80 via-purple-950/40 to-slate-900/90 backdrop-blur-2xl border border-purple-500/30 shadow-[0_8px_32px_0_rgba(0,0,0,0.5)] transition-all duration-300 hover:border-pink-500/60 hover:shadow-pink-500/20 text-white">
          {/* Subtle Ambient Glow */}
          <div className="absolute -top-10 -right-10 w-32 h-32 bg-pink-500/20 rounded-full blur-2xl pointer-events-none group-hover:scale-125 transition-transform duration-500" />

          <div className="relative z-10 flex flex-col sm:flex-row items-center gap-5">
            {/* Instagram QR Container */}
            <a
              href={instagramUrl}
              target="_blank"
              rel="noopener noreferrer"
              title="Scan QR Code or Tap to Open @solarbrighttechnologies on Instagram"
              className="relative block shrink-0 bg-white p-3 rounded-2xl shadow-lg border-2 border-pink-500/40 hover:border-pink-500 transition-all duration-300 hover:scale-105 group/qr text-center"
            >
              <div className="relative w-32 h-32 sm:w-36 sm:h-36 mx-auto flex items-center justify-center bg-white rounded-xl overflow-hidden">
                <img
                  src={instagramQrPng}
                  alt="Solar Bright Technologies Instagram QR Code"
                  className="w-full h-full object-contain"
                  onError={(e) => {
                    const target = e.currentTarget;
                    if (target.src !== instagramQrSvg) {
                      target.src = instagramQrSvg;
                    }
                  }}
                />

                {/* Instagram Camera Logo Overlay in Center */}
                <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                  <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-amber-500 via-pink-600 to-purple-600 p-1.5 shadow-md flex items-center justify-center text-white">
                    <svg
                      className="w-full h-full"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <rect x="2" y="2" width="20" height="20" rx="5" ry="5" />
                      <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
                      <line x1="17.5" y1="6.5" x2="17.51" y2="6.5" />
                    </svg>
                  </div>
                </div>
              </div>

              <p className="mt-2 text-[10px] font-black tracking-wider text-slate-950 uppercase font-sans">
                SOLARBRIGHTTECHNOLOGIES
              </p>
              <span className="text-[9px] text-pink-600 font-bold block">Scan or Tap to Open</span>
            </a>

            {/* Instagram Profile Details */}
            <div className="space-y-2.5 text-center sm:text-left flex-1">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-gradient-to-r from-pink-500/20 via-purple-500/20 to-amber-500/20 border border-pink-500/30 rounded-full text-[11px] font-bold text-pink-300">
                <Sparkles className="w-3.5 h-3.5 text-pink-400" />
                <span>Official Instagram Handle</span>
              </div>

              <div>
                <h4 className="text-lg font-black text-white tracking-tight font-display">
                  @solarbrighttechnologies
                </h4>
                <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                  Scan this QR code with your smartphone camera or click below to explore our latest solar installations, reels, Bikaner site updates, and client reviews on Instagram.
                </p>
              </div>

              <div className="pt-1 flex flex-wrap items-center justify-center sm:justify-start gap-2">
                <a
                  href={instagramUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-gradient-to-r from-amber-500 via-pink-600 to-purple-600 hover:from-amber-600 hover:via-pink-700 hover:to-purple-700 text-white font-bold text-xs shadow-lg shadow-pink-500/25 transition-all duration-200 hover:-translate-y-0.5"
                >
                  <svg className="w-3.5 h-3.5 fill-white" viewBox="0 0 24 24">
                    <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z" />
                  </svg>
                  <span>Follow @solarbrighttechnologies</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
                <span className="text-[11px] text-pink-200 font-medium">
                  Daily Reels & Project Videos
                </span>
              </div>
            </div>

          </div>
        </div>

      </div>

    </div>
  );
};
