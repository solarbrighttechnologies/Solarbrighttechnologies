import React from 'react';
import { Phone, Mail, MapPin, ArrowUpRight, Award, ShieldCheck, MessageSquare } from 'lucide-react';
import { SolarLogo } from './SolarLogo';
import { InstagramQrCard } from './InstagramQrCard';

interface FooterProps {
  onOpenCodeModal: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenCodeModal }) => {
  const whatsappQuotationUrl = "https://wa.me/917852044655?text=Hello%20DINESH%20SIR%20,%20I%20need%20a%20solar%20quotation.";

  return (
    <footer className="bg-slate-950/80 backdrop-blur-2xl text-slate-300 pt-16 pb-12 border-t border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Main Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 pb-12 border-b border-white/10">
          
          {/* Brand Info */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-3">
              <SolarLogo className="w-12 h-10" lightText={true} />
            </div>

            <p className="text-xs text-slate-400 leading-relaxed max-w-sm">
              <strong>Solar Bright Technologies</strong> is a premier <strong>solar consultancy company</strong> that provides more efficient and accurate requirement fulfillment for homes, businesses, and farms in Bikaner. Managed by <strong>Dinesh Sir</strong> in Mukta Prasad Colony.
            </p>

            <div className="flex flex-col gap-1.5 text-xs text-amber-400 font-bold">
              <div className="flex items-center gap-1.5">
                <Award className="w-4 h-4 text-amber-500" />
                <span>REGISTERED ENTERPRISE · BIKANER, RAJASTHAN</span>
              </div>
              <div className="flex items-center gap-1.5 text-amber-300">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>SERVICES PROVIDE PRESENT ONLY IN BIKANER</span>
              </div>
            </div>

            <div className="pt-2 flex items-center gap-3">
              <button
                onClick={onOpenCodeModal}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-xs font-semibold text-amber-400 border border-amber-500/30 transition-all"
              >
                <span>Export Standalone HTML</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </button>

              <a
                href={whatsappQuotationUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-950 text-emerald-400 border border-emerald-500/40 text-xs font-bold hover:bg-emerald-900 transition-all"
              >
                <MessageSquare className="w-3.5 h-3.5" />
                <span>WhatsApp Quotation</span>
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-white">
              Quick Navigation
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <a href="#home" className="hover:text-amber-400 transition-colors">
                  Home
                </a>
              </li>
              <li>
                <a href="#office" className="hover:text-amber-400 transition-colors">
                  Bikaner Office & Team
                </a>
              </li>
              <li>
                <a href="#services" className="hover:text-amber-400 transition-colors">
                  Consultancy & Services
                </a>
              </li>
              <li>
                <a href="#structure" className="hover:text-amber-400 transition-colors">
                  Mounting Structures
                </a>
              </li>
              <li>
                <a href="#calculator" className="hover:text-amber-400 transition-colors">
                  ROI Savings Calculator
                </a>
              </li>
              <li>
                <a href="#projects" className="hover:text-amber-400 transition-colors">
                  Completed Projects
                </a>
              </li>
              <li>
                <a href="#contact" className="hover:text-amber-400 transition-colors">
                  Get Solar Quotation
                </a>
              </li>
            </ul>
          </div>

          {/* Solutions Active in Bikaner */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-white">
              Services in Bikaner
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <a href="#services" className="hover:text-amber-400 transition-colors">
                  Solar Plant Installation
                </a>
              </li>
              <li>
                <a href="#services" className="hover:text-amber-400 transition-colors">
                  Rooftop Solar Systems
                </a>
              </li>
              <li>
                <a href="#services" className="hover:text-amber-400 transition-colors">
                  Solar Maintenance & Repair
                </a>
              </li>
              <li>
                <a href="#services" className="hover:text-amber-400 transition-colors">
                  Solar Panel Cleaning Services
                </a>
              </li>
              <li>
                <a href="#structure" className="hover:text-amber-400 transition-colors">
                  Civil & Structural Works
                </a>
              </li>
              <li>
                <a href="#contact" className="hover:text-amber-400 transition-colors">
                  PM Surya Ghar Subsidy
                </a>
              </li>
            </ul>
          </div>

          {/* Contact Details */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-white">
              Bikaner Office
            </h4>
            <ul className="space-y-2.5 text-xs">
              <li className="flex items-center gap-2">
                <Phone className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                <a href="tel:7852044655" className="hover:text-white transition-colors font-bold text-white">
                  +91 78520 44655 (Dinesh Sir)
                </a>
              </li>
              <li className="flex items-center gap-2">
                <Mail className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                <a href="mailto:solarbrighttechnologies@gmail.com" className="hover:text-white transition-colors break-all">
                  solarbrighttechnologies@gmail.com
                </a>
              </li>
              <li className="flex items-start gap-2">
                <MapPin className="w-3.5 h-3.5 text-amber-500 shrink-0 mt-0.5" />
                <span>
                  Mukta Prasad Colony, Bikaner, Rajasthan
                </span>
              </li>
              <li className="pt-2 text-amber-400 font-extrabold flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
                <span>SERVICES PROVIDE PRESENT ONLY IN BIKANER</span>
              </li>
            </ul>
          </div>

        </div>

        {/* Official Instagram Handle & QR Code */}
        <div className="py-8 border-b border-white/10">
          <InstagramQrCard />
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-4">
          <p>© 2026 Solar Bright Technologies · Enterprise Manager: Dinesh Yadav · Bikaner, Rajasthan</p>
          <div className="flex items-center gap-4">
            <span className="text-amber-400 font-semibold">REGISTERED ENTERPRISE · SOLAR CONSULTANCY</span>
          </div>
        </div>

      </div>
    </footer>
  );
};
