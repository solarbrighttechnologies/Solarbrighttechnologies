import React from 'react';
import { Phone, Mail, MapPin, MessageSquare, CheckCircle2, ExternalLink, Sparkles } from 'lucide-react';
import { InstagramQrCard } from './InstagramQrCard';

interface ContactSectionProps {
  prefilledCapacity?: number;
  prefilledBill?: number;
}

export const ContactSection: React.FC<ContactSectionProps> = ({
  prefilledCapacity,
}) => {
  const whatsappQuotationUrl = "https://wa.me/917852044655?text=Hello%20DINESH%20SIR%20,%20I%20need%20a%20solar%20quotation.";
  const googleFormUrl = "https://docs.google.com/forms/d/e/1FAIpQLScXMhP7znLthmYJ9_nhv4_jP_xnSf0dYrglA8-3zFdpKjz32A/viewform";
  const googleFormEmbedUrl = "https://docs.google.com/forms/d/e/1FAIpQLScXMhP7znLthmYJ9_nhv4_jP_xnSf0dYrglA8-3zFdpKjz32A/viewform?embedded=true";

  return (
    <section id="contact" className="py-20 bg-slate-900/40 backdrop-blur-xl border-y border-white/10 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-amber-500 text-slate-950 rounded-full text-xs font-extrabold mb-3 shadow-md shadow-amber-500/20">
            <span>SERVICES PROVIDE PRESENT ONLY IN BIKANER</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white mt-2 font-display">
            Official Solar Quotation & Requirement Form
          </h2>
          <p className="text-base text-slate-300 mt-4 leading-relaxed">
            Fill in the official Google Form below to request an accurate quotation from <strong>Dinesh Sir (Enterprise Manager)</strong>, or chat directly on WhatsApp.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          
          {/* Left Column: Direct Contact Details & WhatsApp */}
          <div className="lg:col-span-5 space-y-6">
            
            <div className="bg-slate-900/70 backdrop-blur-2xl text-white p-8 rounded-3xl border border-white/10 shadow-[0_8px_32px_0_rgba(0,0,0,0.5)] space-y-6">
              <div>
                <span className="text-xs uppercase font-bold text-amber-400 tracking-wider">
                  REGISTERED ENTERPRISE · BIKANER
                </span>
                <h3 className="text-xl font-bold font-display text-white mt-1">Direct Contact Channels</h3>
                <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                  Connect with Dinesh Sir for personalized consultancy and accurate solar sizing.
                </p>
              </div>

              <div className="space-y-4 pt-2">
                
                {/* Phone */}
                <a
                  href="tel:7852044655"
                  className="flex items-start gap-4 text-slate-200 hover:text-amber-400 transition-colors group p-2.5 rounded-xl hover:bg-slate-800/70"
                >
                  <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0 group-hover:scale-110 transition-transform">
                    <Phone className="w-5 h-5 text-amber-400" />
                  </div>
                  <div>
                    <span className="text-[11px] text-slate-400 block font-medium">Direct Mobile Hotline</span>
                    <span className="text-base font-bold text-white tracking-wide">+91 78520 44655</span>
                    <span className="text-[10px] text-amber-400 font-semibold block mt-0.5">Talk to Dinesh Sir (Manager)</span>
                  </div>
                </a>

                {/* WhatsApp with exact requested message: Hello DINESH SIR , I need a solar quotation. */}
                <a
                  href={whatsappQuotationUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-start gap-4 text-slate-200 hover:text-emerald-400 transition-colors group p-2.5 rounded-xl hover:bg-slate-800/70"
                >
                  <div className="w-10 h-10 rounded-xl bg-emerald-950 text-emerald-400 flex items-center justify-center shrink-0 group-hover:scale-110 transition-transform">
                    <MessageSquare className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-[11px] text-slate-400 block font-medium">WhatsApp Quotation Hotline</span>
                    <span className="text-sm font-bold text-white">7852044655 (Instant)</span>
                    <span className="text-[10px] text-emerald-400 font-semibold block mt-0.5">Click: Hello DINESH SIR , I need a solar quotation.</span>
                  </div>
                </a>

                {/* Email */}
                <a
                  href="mailto:solarbrighttechnologies@gmail.com"
                  className="flex items-start gap-4 text-slate-200 hover:text-amber-400 transition-colors group p-2.5 rounded-xl hover:bg-slate-800/70"
                >
                  <div className="w-10 h-10 rounded-xl bg-slate-800 text-amber-400 flex items-center justify-center shrink-0 group-hover:scale-110 transition-transform">
                    <Mail className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-[11px] text-slate-400 block font-medium">Official Email</span>
                    <span className="text-xs font-bold text-white break-all">solarbrighttechnologies@gmail.com</span>
                  </div>
                </a>

                {/* Office Location */}
                <div className="flex items-start gap-4 text-slate-200 p-2.5">
                  <div className="w-10 h-10 rounded-xl bg-slate-800 text-amber-400 flex items-center justify-center shrink-0">
                    <MapPin className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-[11px] text-slate-400 block font-medium">Experience Center & Office</span>
                    <span className="text-xs font-semibold text-slate-200 leading-relaxed block mt-0.5">
                      Mukta Prasad Colony, Bikaner, Rajasthan
                    </span>
                    <span className="text-[10px] text-amber-400 font-extrabold block mt-1 tracking-wide">
                      SERVICES PROVIDE PRESENT ONLY IN BIKANER
                    </span>
                  </div>
                </div>

              </div>

              {/* Instant WhatsApp Quick Button */}
              <div className="pt-2">
                <a
                  href={whatsappQuotationUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs transition-all shadow-md shadow-emerald-600/30"
                >
                  <MessageSquare className="w-4 h-4" />
                  <span>Send WhatsApp Message to Dinesh Sir</span>
                </a>
              </div>

            </div>

          </div>

          {/* Right Column: Google Form ONLY (Quick Form removed as requested) */}
          <div className="lg:col-span-7 bg-slate-900/70 backdrop-blur-2xl p-6 sm:p-8 rounded-3xl border border-white/10 shadow-[0_8px_32px_0_rgba(0,0,0,0.5)] space-y-4 text-white">
            
            {prefilledCapacity && (
              <div className="p-3 bg-amber-500/15 border border-amber-500/30 rounded-xl text-xs text-amber-300 flex items-center justify-between">
                <span>
                  Estimated Capacity: <strong>{prefilledCapacity.toFixed(1)} kW Plant</strong>
                </span>
                <span className="font-semibold text-amber-400">Enter this in the form below</span>
              </div>
            )}

            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-3 border-b border-white/10">
              <div>
                <h3 className="text-xl font-bold font-display text-white flex items-center gap-2">
                  <span>Official Solar Quotation Form</span>
                  <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Direct submission to Solar Bright Technologies Bikaner database
                </p>
              </div>

              <a
                href={googleFormUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-sm transition-all shrink-0"
              >
                <span>Open in Full Window</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>

            {/* Embedded Google Form Container */}
            <div className="w-full rounded-2xl overflow-hidden border border-slate-200 bg-slate-50 relative min-h-[640px]">
              <iframe
                id="google-form-iframe"
                title="Solar Bright Technologies Lead Form"
                src={googleFormEmbedUrl}
                width="100%"
                height="680"
                className="w-full rounded-xl bg-white border-0"
                loading="lazy"
              >
                Loading Google Form…
              </iframe>
            </div>

            <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-600 flex items-center justify-between">
              <span>Need help? Call Dinesh Sir directly at <strong>+91 78520 44655</strong></span>
              <a href="tel:7852044655" className="text-amber-700 font-bold hover:underline">Call Now</a>
            </div>

          </div>

        </div>

        {/* Instagram ID & QR Code Connection Card */}
        <div className="mt-14 pt-10 border-t border-slate-200">
          <InstagramQrCard />
        </div>

      </div>
    </section>
  );
};
