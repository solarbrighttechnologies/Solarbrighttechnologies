import React, { useState, useEffect } from 'react';
import { ArrowUp, MessageSquare, Phone } from 'lucide-react';

export const FloatingActions: React.FC = () => {
  const [showBackToTop, setShowBackToTop] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setShowBackToTop(window.scrollY > 400);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const whatsappQuotationUrl = "https://wa.me/917852044655?text=Hello%20DINESH%20SIR%20,%20I%20need%20a%20solar%20quotation.";

  return (
    <>
      {/* Floating Action Strip */}
      <div className="fixed bottom-6 right-6 z-40 flex flex-col items-end gap-3">
        {/* Floating Quick Call Button for 7852044655 */}
        <a
          href="tel:7852044655"
          aria-label="Call Dinesh Sir at 7852044655"
          className="w-12 h-12 bg-amber-400 hover:bg-amber-300 text-slate-950 rounded-full shadow-xl flex items-center justify-center transition-all duration-300 hover:scale-110 shadow-amber-500/30 border border-amber-300/40"
          title="Call Dinesh Sir: 7852044655"
        >
          <Phone className="w-5 h-5 text-slate-950" />
        </a>

        {/* Floating WhatsApp Action Button with exact requested message: Hello DINESH SIR , I need a solar quotation. */}
        <a
          href={whatsappQuotationUrl}
          target="_blank"
          rel="noopener noreferrer"
          aria-label="WhatsApp Dinesh Sir: Hello DINESH SIR , I need a solar quotation."
          className="w-14 h-14 bg-emerald-500/95 hover:bg-emerald-500 backdrop-blur-md text-white rounded-full shadow-2xl flex items-center justify-center transition-all duration-300 hover:scale-110 shadow-emerald-500/40 group border border-emerald-400/40"
          title="WhatsApp Dinesh Sir: 7852044655"
        >
          <MessageSquare className="w-7 h-7" />
          <span className="sr-only">Chat on WhatsApp</span>
        </a>
      </div>

      {/* Floating Back to Top Button */}
      {showBackToTop && (
        <button
          type="button"
          onClick={scrollToTop}
          aria-label="Back to Top"
          className="fixed bottom-28 left-6 z-40 w-10 h-10 bg-slate-900/70 hover:bg-slate-900/90 backdrop-blur-xl border border-white/15 text-white rounded-full shadow-lg flex items-center justify-center text-sm transition-all duration-300 hover:scale-105"
        >
          <ArrowUp className="w-5 h-5" />
        </button>
      )}
    </>
  );
};
