import React from 'react';
import { Award, ShieldCheck, ArrowRight, Calculator, Leaf, Sparkles, Phone, MapPin, CheckCircle2, MessageSquare, Compass } from 'lucide-react';
import { SolarTeamPoster } from './SolarTeamPoster';
import heroPosterImage from '../assets/images/regenerated_image_1792217418163.png';

export const Hero: React.FC = () => {
  const whatsappQuotationUrl = "https://wa.me/917852044655?text=Hello%20DINESH%20SIR%20,%20I%20need%20a%20solar%20quotation.";

  return (
    <section id="home" className="relative overflow-hidden bg-slate-900/30 backdrop-blur-xl border-b border-white/10 pt-6 pb-16 lg:pt-10 lg:pb-22">
      {/* Decorative gradient glow */}
      <div className="absolute top-0 right-1/4 w-96 h-96 bg-amber-400/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-20 -left-20 w-80 h-80 bg-orange-400/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-8 items-center">
          
          {/* Left Text Column */}
          <div className="lg:col-span-7 space-y-5">
            
            {/* Registered Enterprise & Exclusive Bikaner Tag */}
            <div className="flex flex-wrap items-center gap-2 text-xs font-semibold">
              <span className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-amber-500 text-slate-950 rounded-full font-extrabold tracking-wide shadow-md shadow-amber-500/20">
                <MapPin className="w-3.5 h-3.5 text-slate-950" />
                <span>SERVICES PROVIDE PRESENT ONLY IN BIKANER</span>
              </span>
              <span className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-sky-500/15 text-sky-300 rounded-full border border-sky-400/30 font-bold backdrop-blur-md">
                <Award className="w-3.5 h-3.5 text-sky-400" />
                <span>REGISTERED ENTERPRISE · BIKANER</span>
              </span>
            </div>

            {/* Main Catchy Headline: Powering A Brighter Tomorrow */}
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-white leading-[1.15] font-display">
              Powering A{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-400 via-amber-300 to-orange-400">
                Brighter Tomorrow
              </span>{' '}
              In Bikaner
            </h1>

            {/* Solar Consultancy Company Description - More Efficient & More Accurate Requirement Fulfillment */}
            <div className="p-5 bg-slate-900/60 backdrop-blur-xl rounded-2xl border border-amber-500/30 space-y-1.5 shadow-xl">
              <div className="flex items-center gap-2 font-bold text-amber-400 text-sm">
                <Compass className="w-4 h-4 text-amber-400 shrink-0" />
                <span>Premier Solar Consultancy Enterprise in Bikaner</span>
              </div>
              <p className="text-xs sm:text-sm text-slate-200 leading-relaxed">
                <strong>Solar Bright Technologies</strong> is a dedicated solar consultancy company providing <strong>more efficient, customized, and accurate requirement fulfillment</strong> for residential homes, agricultural farms, and commercial buildings in Bikaner. Led by Enterprise Manager <strong>Dinesh Sir</strong>.
              </p>
            </div>

            {/* Sub-headline with Dinesh & Solar Bright Technologies */}
            <p className="text-sm sm:text-base text-slate-300 leading-relaxed max-w-2xl">
              From precision satellite roof analysis to heavy-duty rust-resistant structures and Central PM Surya Ghar subsidy clearances up to ₹78,000, we engineer solar power tailored to your exact energy load.
            </p>

            {/* CTAs with updated WhatsApp message: Hello DINESH SIR , I need a solar quotation. */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 pt-1">
              <a
                href={whatsappQuotationUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-2 px-6 py-3.5 text-sm sm:text-base font-bold text-white bg-emerald-600 hover:bg-emerald-500 rounded-xl shadow-lg shadow-emerald-600/30 transition-all duration-200 hover:-translate-y-0.5 text-center"
              >
                <MessageSquare className="w-4 h-4" />
                <span>Get Quotation on WhatsApp</span>
              </a>

              <a
                href="tel:7852044655"
                className="inline-flex items-center justify-center gap-2 px-5 py-3.5 text-sm sm:text-base font-extrabold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded-xl shadow-lg shadow-amber-500/20 transition-all duration-200 text-center"
              >
                <Phone className="w-4 h-4 text-slate-950" />
                <span>Call Dinesh Sir: 7852044655</span>
              </a>

              <a
                href="#calculator"
                className="inline-flex items-center justify-center gap-2 px-4 py-3.5 text-xs sm:text-sm font-semibold text-slate-200 bg-white/10 hover:bg-white/15 border border-white/15 rounded-xl shadow-sm transition-all duration-200 text-center backdrop-blur-md"
              >
                <Calculator className="w-4 h-4 text-amber-400" />
                <span>Calculate Savings</span>
              </a>
            </div>

            {/* 4 Pillars from Posters: High Efficiency, Durable & Long Lasting, Eco Friendly, Maximum Performance */}
            <div className="pt-3 grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-xs font-semibold text-slate-200">
              <div className="flex items-center gap-2 p-2.5 bg-slate-900/60 backdrop-blur-md rounded-xl border border-white/10 shadow-sm">
                <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0" />
                <span>High Efficiency</span>
              </div>
              <div className="flex items-center gap-2 p-2.5 bg-slate-900/60 backdrop-blur-md rounded-xl border border-white/10 shadow-sm">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Durable & Long Lasting</span>
              </div>
              <div className="flex items-center gap-2 p-2.5 bg-slate-900/60 backdrop-blur-md rounded-xl border border-white/10 shadow-sm">
                <CheckCircle2 className="w-4 h-4 text-sky-400 shrink-0" />
                <span>Eco Friendly</span>
              </div>
              <div className="flex items-center gap-2 p-2.5 bg-slate-900/60 backdrop-blur-md rounded-xl border border-white/10 shadow-sm">
                <CheckCircle2 className="w-4 h-4 text-purple-400 shrink-0" />
                <span>Maximum Performance</span>
              </div>
            </div>

            {/* Proof Points Strip */}
            <div className="pt-5 border-t border-white/10 grid grid-cols-3 gap-4 text-left">
              <div>
                <p className="text-xl sm:text-2xl font-extrabold text-white tabular-nums">100% Accurate</p>
                <p className="text-[11px] text-slate-400 font-medium mt-0.5">Requirement Fulfillment</p>
              </div>
              <div>
                <p className="text-xl sm:text-2xl font-extrabold text-white tabular-nums">Up to 100%</p>
                <p className="text-[11px] text-slate-400 font-medium mt-0.5">Electricity Bill Cut</p>
              </div>
              <div>
                <p className="text-xl sm:text-2xl font-extrabold text-white tabular-nums">25 Yrs</p>
                <p className="text-[11px] text-slate-400 font-medium mt-0.5">Linear Warranty</p>
              </div>
            </div>

          </div>

          {/* Right Hero Container: Official Solar Team Poster Showcase as requested */}
          <div className="lg:col-span-5 relative">
            <SolarTeamPoster imageSrc={heroPosterImage} className="w-full max-w-lg mx-auto shadow-2xl" />
          </div>

        </div>

      </div>
    </section>
  );
};
