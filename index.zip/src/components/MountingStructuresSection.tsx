import React from 'react';
import { Shield, Hammer, Link, SunMedium, Wind, CheckCircle2 } from 'lucide-react';

export const MountingStructuresSection: React.FC = () => {
  const structureFeatures = [
    {
      icon: Shield,
      title: 'High Strength Engineering',
      desc: 'Heavy-duty 550 MPA hot-dip galvanized steel engineered to endure high wind loads of up to 160 km/h without deflection.',
      badge: '550 MPA Steel',
    },
    {
      icon: Wind,
      title: 'Corrosion & Rust Resistant',
      desc: 'Thick 80+ micron zinc galvanization and AL6005-T5 anodized aluminum alloy formulated to resist intense desert heat and seasonal dust storms.',
      badge: 'Rust Proof 25+ Yrs',
    },
    {
      icon: Hammer,
      title: 'Zero-Puncture Fast Setup',
      desc: 'Precision pre-punched slotted rails with chemical anchoring and trapezoidal EPDM rubber gaskets that eliminate roof leaks.',
      badge: 'Leak Proof Guarantee',
    },
    {
      icon: Link,
      title: 'Universal Compatibility',
      desc: 'Versatile engineering suitable for all panel formats (Mono PERC, TopCon, Bifacial) and roof types (RCC slabs, tin sheds, elevated terraces).',
      badge: 'All Roof Types',
    },
  ];

  return (
    <section id="structure" className="py-20 bg-slate-900/40 backdrop-blur-xl text-white relative overflow-hidden border-y border-white/10">
      {/* Decorative ambient lights */}
      <div className="absolute top-1/2 left-0 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-sky-500/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-xs font-bold uppercase tracking-widest text-amber-400">
            Civil & Mechanical Engineering
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white mt-2 font-display">
            Strong Foundation. Solid Performance.
          </h2>
          <p className="text-sm sm:text-base text-slate-300 mt-4 leading-relaxed">
            A solar plant is only as reliable as its foundation. Solar Bright Technologies manufactures and installs premium, rust-resistant mounting structures engineered for 25+ years of unyielding support.
          </p>
        </div>

        {/* 4 Feature Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {structureFeatures.map((feat, i) => {
            const Icon = feat.icon;
            return (
              <div
                key={i}
                className="bg-slate-900/60 backdrop-blur-xl rounded-2xl p-6 border border-white/10 hover:border-amber-400/60 hover:shadow-2xl hover:shadow-amber-500/10 hover:-translate-y-1 transition-all duration-300 flex flex-col justify-between"
              >
                <div>
                  <div className="w-12 h-12 rounded-xl bg-amber-500/15 text-amber-400 flex items-center justify-center text-xl mb-5 border border-amber-500/20">
                    <Icon className="w-6 h-6" />
                  </div>
                  <span className="text-[10px] font-bold text-amber-400 uppercase tracking-wider block mb-1">
                    {feat.badge}
                  </span>
                  <h3 className="text-lg font-bold text-white mb-2 font-display">
                    {feat.title}
                  </h3>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    {feat.desc}
                  </p>
                </div>

                <div className="mt-6 pt-4 border-t border-white/10 flex items-center gap-1.5 text-[11px] font-semibold text-emerald-400">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Tested for Rajasthan Climates</span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Bottom Banner */}
        <div className="bg-gradient-to-r from-amber-500/15 via-slate-900/80 to-amber-500/10 backdrop-blur-2xl border border-amber-500/30 rounded-2xl p-6 sm:p-8 flex flex-col sm:flex-row items-center justify-between gap-6 shadow-2xl">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-amber-500 text-slate-950 flex items-center justify-center shrink-0 shadow-md">
              <SunMedium className="w-6 h-6" />
            </div>
            <div>
              <h4 className="text-base font-bold text-white font-display">
                Looking for Custom Elevated Terrace or Shed Structures?
              </h4>
              <p className="text-xs text-slate-300 mt-0.5">
                We design custom heights so you can walk and sit comfortably under your solar rooftop array.
              </p>
            </div>
          </div>

          <a
            href="tel:7852044655"
            className="px-6 py-3 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-extrabold text-xs uppercase tracking-wider whitespace-nowrap shadow-lg shadow-amber-500/20 transition-all shrink-0"
          >
            Consult Structure Engineer: 7852044655
          </a>
        </div>

      </div>
    </section>
  );
};
