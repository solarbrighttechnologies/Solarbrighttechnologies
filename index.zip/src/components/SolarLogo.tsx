import React from 'react';

interface SolarLogoProps {
  className?: string;
  showText?: boolean;
  lightText?: boolean;
}

export const SolarLogo: React.FC<SolarLogoProps> = ({
  className = 'w-11 h-11',
  showText = true,
  lightText = false,
}) => {
  return (
    <div className="flex items-center gap-3">
      {/* SVG Icon matching the official Solar Bright Technologies 2026 emblem */}
      <svg
        viewBox="0 0 200 160"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className={`${className} shrink-0 drop-shadow-sm`}
      >
        <defs>
          {/* Sun Gradient */}
          <linearGradient id="sunGrad" x1="100" y1="20" x2="100" y2="90" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#FDE047" />
            <stop offset="60%" stopColor="#F59E0B" />
            <stop offset="100%" stopColor="#EA580C" />
          </linearGradient>

          {/* Panel Gradient */}
          <linearGradient id="panelGrad" x1="40" y1="65" x2="160" y2="105" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#38BDF8" />
            <stop offset="35%" stopColor="#0284C7" />
            <stop offset="100%" stopColor="#0369A1" />
          </linearGradient>

          <linearGradient id="panelCell" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#0284C7" />
            <stop offset="100%" stopColor="#075985" />
          </linearGradient>
        </defs>

        {/* Sun Rays radiating outwards */}
        <g stroke="#F59E0B" strokeWidth="5" strokeLinecap="round">
          <line x1="100" y1="12" x2="100" y2="24" />
          <line x1="75" y1="18" x2="80" y2="29" />
          <line x1="125" y1="18" x2="120" y2="29" />
          <line x1="53" y1="31" x2="62" y2="40" />
          <line x1="147" y1="31" x2="138" y2="40" />
          <line x1="38" y1="52" x2="49" y2="58" />
          <line x1="162" y1="52" x2="151" y2="58" />
          <line x1="30" y1="76" x2="42" y2="78" />
          <line x1="170" y1="76" x2="158" y2="78" />
        </g>

        {/* Golden Sun Semi-Circle */}
        <path
          d="M 52 78 A 48 48 0 0 1 148 78 Z"
          fill="url(#sunGrad)"
        />

        {/* Gloss highlight on sun */}
        <ellipse cx="100" cy="55" rx="32" ry="18" fill="#FEF08A" opacity="0.65" />

        {/* Arched Photovoltaic Solar Panel Module Cluster */}
        <g transform="translate(0, 0)">
          {/* Row 1 */}
          <rect x="72" y="65" width="16" height="11" rx="1.5" fill="url(#panelCell)" stroke="#FFFFFF" strokeWidth="1" />
          <rect x="91" y="65" width="18" height="11" rx="1.5" fill="url(#panelCell)" stroke="#FFFFFF" strokeWidth="1" />
          <rect x="112" y="65" width="16" height="11" rx="1.5" fill="url(#panelCell)" stroke="#FFFFFF" strokeWidth="1" />

          {/* Row 2 */}
          <rect x="52" y="79" width="16" height="12" rx="1.5" fill="url(#panelCell)" stroke="#FFFFFF" strokeWidth="1" transform="rotate(-6 60 85)" />
          <rect x="71" y="79" width="17" height="12" rx="1.5" fill="url(#panelCell)" stroke="#FFFFFF" strokeWidth="1" transform="rotate(-2 79 85)" />
          <rect x="91" y="79" width="18" height="12" rx="1.5" fill="url(#panelCell)" stroke="#FFFFFF" strokeWidth="1" />
          <rect x="112" y="79" width="17" height="12" rx="1.5" fill="url(#panelCell)" stroke="#FFFFFF" strokeWidth="1" transform="rotate(2 120 85)" />
          <rect x="132" y="79" width="16" height="12" rx="1.5" fill="url(#panelCell)" stroke="#FFFFFF" strokeWidth="1" transform="rotate(6 140 85)" />

          {/* Row 3 */}
          <rect x="46" y="94" width="17" height="13" rx="1.5" fill="url(#panelCell)" stroke="#FFFFFF" strokeWidth="1" transform="rotate(-9 54 100)" />
          <rect x="66" y="94" width="18" height="13" rx="1.5" fill="url(#panelCell)" stroke="#FFFFFF" strokeWidth="1" transform="rotate(-4 75 100)" />
          <rect x="88" y="94" width="24" height="13" rx="1.5" fill="url(#panelCell)" stroke="#FFFFFF" strokeWidth="1" />
          <rect x="116" y="94" width="18" height="13" rx="1.5" fill="url(#panelCell)" stroke="#FFFFFF" strokeWidth="1" transform="rotate(4 125 100)" />
          <rect x="137" y="94" width="17" height="13" rx="1.5" fill="url(#panelCell)" stroke="#FFFFFF" strokeWidth="1" transform="rotate(9 145 100)" />
        </g>

        {/* Curved Foundation Arc with "2026" */}
        <path
          d="M 68 116 Q 100 126 132 116"
          stroke="#F59E0B"
          strokeWidth="2.5"
          fill="none"
          strokeLinecap="round"
        />
        <text
          x="100"
          y="125"
          fill="#0369A1"
          fontSize="11"
          fontWeight="bold"
          fontFamily="system-ui, sans-serif"
          textAnchor="middle"
          letterSpacing="2"
        >
          2026
        </text>
      </svg>

      {/* Brand Text */}
      {showText && (
        <div className="flex flex-col">
          <div className="flex items-center gap-1.5">
            <span
              className={`text-lg sm:text-xl font-extrabold tracking-tight font-display leading-none ${
                lightText ? 'text-white' : 'text-slate-900'
              }`}
            >
              SOLAR BRIGHT
            </span>
          </div>
          <span
            className={`text-[11px] font-bold tracking-widest uppercase leading-tight ${
              lightText ? 'text-sky-400' : 'text-sky-600'
            }`}
          >
            TECHNOLOGIES
          </span>
          <span
            className={`text-[9px] font-bold tracking-normal mt-0.5 ${
              lightText ? 'text-amber-400' : 'text-amber-700'
            }`}
          >
            Registered Enterprise · Bikaner, Rajasthan
          </span>
        </div>
      )}
    </div>
  );
};
