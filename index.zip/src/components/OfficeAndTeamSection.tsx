import React from 'react';
import { Phone, Mail, MapPin, Award, CheckCircle2, ShieldCheck, Wrench, Sparkles, Building, UserCheck, MessageSquare, Compass, Shield, Zap } from 'lucide-react';
import { SolarTeamPoster } from './SolarTeamPoster';
import officePosterImage from '../assets/images/regenerated_image_1792217422371.png';

export const OfficeAndTeamSection: React.FC = () => {
  const whatsappUrl = "https://wa.me/917852044655?text=Hello%20DINESH%20SIR%20,%20I%20need%20a%20solar%20quotation.";

  return (
    <section id="office" className="py-20 bg-slate-900/40 backdrop-blur-xl border-b border-white/10 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-amber-500 text-slate-950 rounded-full text-xs font-extrabold mb-3 shadow-md shadow-amber-500/20">
            <Award className="w-4 h-4 text-slate-950" />
            <span>REGISTERED ENTERPRISE · BIKANER, RAJASTHAN</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white font-display">
            Solar Bright Technologies Experience Center & Team
          </h2>
          <p className="text-base text-slate-300 mt-4 leading-relaxed">
            We are a premier <strong>solar consultancy company</strong> dedicated to delivering <strong>more efficient and more accurate requirement fulfillment in Bikaner</strong>. Led by Enterprise Manager <strong>Dinesh Sir</strong> at our Mukta Prasad Colony office.
          </p>
        </div>

        {/* 2-Column Showcase */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          
          {/* Left Column: Official SOLAR TEAM Graphic Poster */}
          <div className="lg:col-span-6">
            <SolarTeamPoster imageSrc={officePosterImage} className="w-full max-w-xl mx-auto shadow-2xl" />
          </div>

          {/* Right Column: Office Capabilities & Direct Management */}
          <div className="lg:col-span-6 space-y-6">
            
            <div className="bg-slate-900/70 backdrop-blur-2xl rounded-3xl p-6 sm:p-8 border border-white/10 shadow-[0_8px_32px_0_rgba(0,0,0,0.5)] space-y-6">
              
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/10 pb-4">
                <div>
                  <span className="text-xs font-bold uppercase tracking-wider text-amber-400">
                    Bikaner Headquarters & Experience Center
                  </span>
                  <h3 className="text-2xl font-extrabold text-white mt-0.5 font-display">
                    Mukta Prasad Colony, Bikaner
                  </h3>
                </div>
                <span className="text-xs font-extrabold bg-amber-500/15 text-amber-300 px-3 py-1.5 rounded-full border border-amber-500/30">
                  SERVICES IN BIKANER ONLY
                </span>
              </div>

              {/* Consultancy Mission Banner */}
              <div className="p-4 bg-slate-950/60 backdrop-blur-md rounded-2xl border border-amber-500/30 flex items-start gap-3">
                <Compass className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-sm font-bold text-amber-400">
                    Accurate Requirement Sizing & Zero Extra Cost
                  </h4>
                  <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                    Unlike standard vendors who push fixed packages, our consultancy analyzes your exact hourly electrical load, available shadow-free terrace area, and DISCOM sanctioned load to fulfill your requirements with maximum efficiency.
                  </p>
                </div>
              </div>

              {/* Showroom Features Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 text-xs text-slate-300">
                <div className="p-3.5 bg-slate-950/60 backdrop-blur-md rounded-2xl border border-white/10 space-y-1">
                  <div className="flex items-center gap-2 font-bold text-white text-xs">
                    <Building className="w-4 h-4 text-amber-400" />
                    <span>Live Hardware Displays</span>
                  </div>
                  <p className="text-slate-400 text-[11px] leading-relaxed">
                    Physical Mono PERC panels, hybrid inverters, and heavy hot-dip galvanized mounting structures.
                  </p>
                </div>

                <div className="p-3.5 bg-slate-950/60 backdrop-blur-md rounded-2xl border border-white/10 space-y-1">
                  <div className="flex items-center gap-2 font-bold text-white text-xs">
                    <ShieldCheck className="w-4 h-4 text-emerald-400" />
                    <span>Local Bikaner Support</span>
                  </div>
                  <p className="text-slate-400 text-[11px] leading-relaxed">
                    Prompt on-ground response for installation, maintenance, and regular panel cleaning in Bikaner.
                  </p>
                </div>

                <div className="p-3.5 bg-slate-950/60 backdrop-blur-md rounded-2xl border border-white/10 space-y-1">
                  <div className="flex items-center gap-2 font-bold text-white text-xs">
                    <Wrench className="w-4 h-4 text-sky-400" />
                    <span>Fast Certified Setup</span>
                  </div>
                  <p className="text-slate-400 text-[11px] leading-relaxed">
                    Strict adherence to MNRE electrical compliance standards with zero roof-leakage anchoring.
                  </p>
                </div>

                <div className="p-3.5 bg-slate-950/60 backdrop-blur-md rounded-2xl border border-white/10 space-y-1">
                  <div className="flex items-center gap-2 font-bold text-white text-xs">
                    <Sparkles className="w-4 h-4 text-purple-400" />
                    <span>PM Surya Ghar Subsidy</span>
                  </div>
                  <p className="text-slate-400 text-[11px] leading-relaxed">
                    Direct assistance for portal submission, DISCOM net-metering, and up to ₹78,000 DBT bank credit.
                  </p>
                </div>
              </div>

              {/* Manager & Direct Contact Strip */}
              <div className="pt-4 border-t border-white/10 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-amber-500 text-slate-950 font-black text-lg flex items-center justify-center shrink-0 shadow-md">
                    DY
                  </div>
                  <div>
                    <h4 className="text-sm font-extrabold text-white">Dinesh Sir</h4>
                    <p className="text-xs text-amber-400 font-bold">Enterprise Manager · Solar Bright Technologies</p>
                    <p className="text-[11px] text-slate-400">+91 78520 44655</p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <a
                    href="tel:7852044655"
                    className="flex-1 sm:flex-none inline-flex items-center justify-center gap-1.5 px-4 py-2.5 bg-amber-400 hover:bg-amber-300 text-slate-950 font-extrabold text-xs rounded-xl shadow-md transition-all"
                  >
                    <Phone className="w-3.5 h-3.5 text-slate-950" />
                    <span>Call</span>
                  </a>
                  <a
                    href={whatsappUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex-1 sm:flex-none inline-flex items-center justify-center gap-1.5 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl shadow-md shadow-emerald-600/30 transition-all"
                  >
                    <MessageSquare className="w-3.5 h-3.5" />
                    <span>WhatsApp</span>
                  </a>
                </div>
              </div>

            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
