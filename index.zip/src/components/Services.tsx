import React, { useState } from 'react';
import { ArrowRight, CheckCircle2, X } from 'lucide-react';

interface ServiceDetail {
  id: string;
  title: string;
  badge: string;
  badgeColor: string;
  image: string;
  fallbackPlaceholder: string;
  summary: string;
  fullDescription: string;
  highlights: string[];
  specs: { label: string; value: string }[];
}

export const Services: React.FC = () => {
  const [selectedService, setSelectedService] = useState<ServiceDetail | null>(null);

  const servicesList: ServiceDetail[] = [
    {
      id: 'residential',
      title: 'Residential Solar Rooftop',
      badge: '1 kW – 15 kW Systems',
      badgeColor: 'bg-amber-500 text-white',
      // <!-- PHOTO: Rooftop Solar on Residential House -->
      image: 'https://images.unsplash.com/photo-1509391365360-2e959784a276?auto=format&fit=crop&w=800&q=80',
      fallbackPlaceholder: 'https://placehold.co/400x250?text=Residential+Home+Solar',
      summary:
        'Customized solar rooftop solutions for independent villas, row houses, and gated housing societies in Bikaner. Zero roof damage and max savings.',
      fullDescription:
        'Transform your home roof into a miniature powerhouse. Our high-efficiency Mono PERC panels generate clean energy even during low-light winter mornings. Combined with bi-directional net metering, our residential setups lower power bills by up to 100% while earning you ₹78,000 direct bank subsidy from the central government.',
      highlights: [
        'Central Govt. PM Surya Ghar subsidy of up to ₹78,000',
        'Mono PERC Half-cut modules with 22%+ cell efficiency',
        'Walkable, elevated structure designs that preserve terrace use',
        'Zero-puncture chemical anchoring for leak-proof roofs',
      ],
      specs: [
        { label: 'System Capacity', value: '1 kW to 15 kW' },
        { label: 'Roof Area Required', value: '80–100 sq.ft per kW' },
        { label: 'Avg. Monthly Yield', value: '120–130 Units / kW' },
        { label: 'Warranty', value: '25 Years Linear Performance' },
      ],
    },
    {
      id: 'commercial',
      title: 'Commercial & Industrial Solar',
      badge: '20 kW – 500+ kW Plants',
      badgeColor: 'bg-blue-600 text-white',
      // <!-- PHOTO: Commercial Factory & Warehouse Rooftop Solar Array -->
      image: 'https://images.unsplash.com/photo-1613665813446-82a78c468a1d?auto=format&fit=crop&w=800&q=80',
      fallbackPlaceholder: 'https://placehold.co/400x250?text=Commercial+Solar+Plant',
      summary:
        'High-yield solar plants for factories, cold storages, warehouses, educational institutions, and hospitals with 40% accelerated depreciation.',
      fullDescription:
        'Commercial and industrial power tariffs are typically the steepest. Solar Bright Technologies provides comprehensive EPC (Engineering, Procurement, Construction) for flat roofs, metal sheds, and open spaces in Bikaner. Take advantage of 40% accelerated depreciation tax benefits, reducing corporate tax liability in year one.',
      highlights: [
        '40% Accelerated Depreciation tax benefit under IT Act',
        'Fast payback between 2.8 to 3.8 years',
        'Custom trapezoidal clamps for tin and metal shed installations',
        'Smart SCADA & weather-station integrated remote telemetry',
      ],
      specs: [
        { label: 'System Capacity', value: '20 kW to 500+ kW' },
        { label: 'Target Tariffs', value: 'HT / Commercial Tariff' },
        { label: 'Structural Grade', value: 'Galvanized 550 MPA Steel / Al' },
        { label: 'Inverter Type', value: 'Multi-MPPT High Yield String' },
      ],
    },
    {
      id: 'pumps',
      title: 'Agricultural Solar Water Pumps',
      badge: '3 HP – 10 HP Systems',
      badgeColor: 'bg-emerald-600 text-white',
      // <!-- PHOTO: Agricultural Solar Water Pump in Farm -->
      image: 'https://images.unsplash.com/photo-1625246333195-78d9c38ad449?auto=format&fit=crop&w=800&q=80',
      fallbackPlaceholder: 'https://placehold.co/400x250?text=Agricultural+Solar+Pumps',
      summary:
        'Dependable DC and AC submersible and surface solar water pumps designed for continuous agricultural irrigation in Rajasthan without diesel worries.',
      fullDescription:
        'Empower your agricultural fields with round-the-clock water reliability. Our solar pumping solutions replace expensive diesel engines and eradicate reliance on unreliable midnight grid supply. Built with stainless steel submersible pump sets and smart solar variable frequency drives (VFD) that automatically modulate pump speed based on sunlight irradiance.',
      highlights: [
        'Eliminate 100% of diesel pump fuel and generator bills',
        'Daylight-synchronized automated variable speed drive',
        'Dry-run and overload smart motor protections built-in',
        'High-discharge stainless steel grade 304 impellers',
      ],
      specs: [
        { label: 'Pump Rating', value: '3 HP, 5 HP, 7.5 HP & 10 HP' },
        { label: 'Discharge Depth', value: 'Up to 450 feet head' },
        { label: 'Drive Controller', value: 'Smart Solar VFD IP65' },
        { label: 'Tracking Structure', value: 'Manual Dual-Axis Seasonal' },
      ],
    },
    {
      id: 'hybrid',
      title: 'Off-Grid & Hybrid Battery Systems',
      badge: 'Lithium / Gel Storage',
      badgeColor: 'bg-purple-600 text-white',
      // <!-- PHOTO: Lithium Battery Energy Storage Bank Mounted on Wall -->
      image: 'https://images.unsplash.com/photo-1548611716-ad782c589b35?auto=format&fit=crop&w=800&q=80',
      fallbackPlaceholder: 'https://placehold.co/400x250?text=Solar+Battery+Storage',
      summary:
        'Smart energy storage systems featuring long-cycle lithium iron phosphate (LiFePO4) batteries and hybrid inverters for total energy independence.',
      fullDescription:
        'Never worry about power outages again. Our hybrid solar systems store excess generation during the day and automatically dispatch battery power during nighttime peak tariff hours or unexpected power cuts. Featuring ultra-reliable LiFePO4 batteries with 6,000+ cycle life.',
      highlights: [
        'Instantaneous 10ms microsecond automatic transfer switch',
        'Tier-1 LiFePO4 chemistry with 10-year battery design life',
        'Seamless integration with both rooftop solar and utility grid',
        'Zero noise, zero fumes, and zero diesel engine maintenance',
      ],
      specs: [
        { label: 'Battery Chemistry', value: 'LiFePO4 Lithium Iron Phosphate' },
        { label: 'Cycle Life', value: '6,000+ cycles at 80% DoD' },
        { label: 'Storage Capacity', value: '5 kWh to 60 kWh modular' },
        { label: 'Switchover Time', value: '< 10 milliseconds (UPS Grade)' },
      ],
    },
  ];

  return (
    <section id="services" className="py-20 bg-slate-900/40 backdrop-blur-xl border-y border-white/10 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-xs font-bold uppercase tracking-widest text-amber-400">
            Tailored Solutions
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white mt-2 font-display">
            Turnkey Solar Solutions for Every Energy Demand
          </h2>
          <p className="text-base text-slate-300 mt-4 leading-relaxed">
            Whether you want to zero out domestic electricity bills, reduce factory operating overheads, or irrigate acres of farmland, we deliver custom-engineered solar arrays.
          </p>
        </div>

        {/* Services 4-Card Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {servicesList.map((service) => (
            <div
              key={service.id}
              className="bg-slate-900/60 hover:bg-slate-800/80 backdrop-blur-xl rounded-2xl overflow-hidden border border-white/10 hover:border-amber-400/40 shadow-xl hover:shadow-2xl hover:shadow-amber-500/10 hover:-translate-y-1 transition-all duration-300 flex flex-col justify-between group text-white"
            >
              <div>
                {/* Image Slot with Editable Comment */}
                <div className="aspect-[16/10] overflow-hidden bg-slate-100 relative">
                  {/* <!-- REPLACE THIS WITH YOUR OWN IMAGE URL: ${service.title} --> */}
                  <img
                    src={service.image}
                    alt={service.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src =
                        "data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 600 375' fill='%230f172a'><rect width='600' height='375'/><circle cx='300' cy='150' r='60' fill='%23f59e0b' opacity='0.5'/><polygon points='100,320 250,220 350,280 500,180 550,320' fill='%230284c7' opacity='0.4'/><text x='300' y='350' fill='%2394a3b8' font-size='18' text-anchor='middle' font-family='sans-serif'>Solar Bright Technologies</text></svg>";
                    }}
                  />
                  <span
                    className={`absolute top-3 left-3 text-[10px] font-bold uppercase px-2.5 py-1 rounded-md shadow-sm ${service.badgeColor}`}
                  >
                    {service.badge}
                  </span>
                </div>

                {/* Card Body */}
                <div className="p-6">
                  <h3 className="text-lg font-bold text-white mb-2 font-display group-hover:text-amber-400 transition-colors">
                    {service.title}
                  </h3>
                  <p className="text-xs text-slate-300 leading-relaxed mb-4">
                    {service.summary}
                  </p>
                </div>
              </div>

              {/* Action Footer */}
              <div className="px-6 pb-6 pt-0 flex items-center justify-between border-t border-white/10 mt-auto pt-4">
                <button
                  onClick={() => setSelectedService(service)}
                  className="inline-flex items-center gap-1.5 text-xs font-bold text-amber-400 hover:text-amber-300 transition-colors"
                >
                  <span>Learn More</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
                <a
                  href="#contact"
                  className="text-[11px] font-semibold text-slate-400 hover:text-white transition-colors"
                >
                  Get Quote
                </a>
              </div>
            </div>
          ))}
        </div>

      </div>

      {/* Detail Modal for Selected Service */}
      {selectedService && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fadeIn">
          <div className="bg-slate-900/90 backdrop-blur-2xl rounded-3xl max-w-2xl w-full max-h-[90vh] overflow-y-auto p-6 sm:p-8 shadow-[0_8px_32px_0_rgba(0,0,0,0.5)] relative border border-white/15 text-white">
            
            <button
              onClick={() => setSelectedService(null)}
              className="absolute top-5 right-5 p-2 rounded-xl text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
              aria-label="Close modal"
            >
              <X className="w-5 h-5" />
            </button>

            <span className={`inline-block text-[11px] font-bold uppercase px-2.5 py-1 rounded-md mb-2 ${selectedService.badgeColor}`}>
              {selectedService.badge}
            </span>

            <h3 className="text-2xl font-extrabold text-white font-display">
              {selectedService.title}
            </h3>

            <p className="text-sm text-slate-300 mt-4 leading-relaxed">
              {selectedService.fullDescription}
            </p>

            {/* Key Highlights */}
            <div className="mt-6 space-y-2.5">
              <h4 className="text-xs font-bold uppercase tracking-wider text-amber-400">
                Key Advantages & Capabilities
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-slate-200">
                {selectedService.highlights.map((item, i) => (
                  <div key={i} className="flex items-start gap-2 bg-slate-950/60 p-2.5 rounded-xl border border-white/10">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <span>{item}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Technical Specifications */}
            <div className="mt-6 pt-6 border-t border-white/10">
              <h4 className="text-xs font-bold uppercase tracking-wider text-amber-400 mb-3">
                System Specifications
              </h4>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
                {selectedService.specs.map((spec, i) => (
                  <div key={i} className="bg-slate-950/60 p-3 rounded-xl border border-white/10">
                    <span className="text-[10px] text-slate-400 font-medium block uppercase tracking-wider">
                      {spec.label}
                    </span>
                    <span className="text-xs font-bold text-white mt-1 block">
                      {spec.value}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Modal Actions */}
            <div className="mt-8 pt-6 border-t border-white/10 flex items-center justify-end gap-3">
              <button
                onClick={() => setSelectedService(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-400 hover:text-white"
              >
                Close
              </button>
              <a
                href="#contact"
                onClick={() => setSelectedService(null)}
                className="px-6 py-2.5 text-xs font-extrabold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded-xl shadow-lg shadow-amber-500/20 transition-all"
              >
                Inquire For This System
              </a>
            </div>

          </div>
        </div>
      )}
    </section>
  );
};
