import React from 'react';
import { ShieldCheck, TrendingDown, Zap, Smartphone, FileCheck2, CircleDollarSign } from 'lucide-react';

export const WhyChooseUs: React.FC = () => {
  const benefits = [
    {
      icon: ShieldCheck,
      iconColor: 'text-amber-600 bg-amber-500/10',
      title: '25-Year Performance Warranty',
      description:
        'We engineer systems using Tier-1 monocrystalline panels guaranteeing over 80% linear power efficiency through year 25.',
    },
    {
      icon: TrendingDown,
      iconColor: 'text-emerald-600 bg-emerald-500/10',
      title: 'Cut Electricity Bills Up to 100%',
      description:
        'Generate self-sustaining clean electricity right on your roof and export surplus power to the local grid through net-metering.',
    },
    {
      icon: Zap,
      iconColor: 'text-blue-600 bg-blue-500/10',
      title: 'Fast Installation',
      description:
        'Pre-engineered anodized aluminum structures and certified solar technicians ensure zero-puncture, lightning-fast roof mounting.',
    },
    {
      icon: Smartphone,
      iconColor: 'text-indigo-600 bg-indigo-500/10',
      title: '24/7 Smart Remote Monitoring',
      description:
        'Watch your daily units generated, grid export credits, and household energy consumption live right from your mobile app.',
    },
    {
      icon: FileCheck2,
      iconColor: 'text-rose-600 bg-rose-500/10',
      title: 'Hassle-Free Govt. Subsidy Liaison',
      description:
        'Our dedicated documentation desk handles the PM Surya Ghar portal registration, DISCOM approvals, and direct DBT account credit.',
    },
    {
      icon: CircleDollarSign,
      iconColor: 'text-cyan-600 bg-cyan-500/10',
      title: 'Zero-Down Green Solar EMI',
      description:
        'Switch with zero upfront capital through subsidized clean energy bank loans. Your monthly electricity savings offset the loan EMI.',
    },
  ];

  return (
    <section id="about" className="py-20 bg-slate-900/30 backdrop-blur-xl border-y border-white/10 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-xs font-bold uppercase tracking-widest text-amber-400">
            Why Solar Bright Technologies
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white mt-2 font-display">
            Engineered for Maximum Efficiency & Lifetime Value
          </h2>
          <p className="text-base text-slate-300 mt-4 leading-relaxed">
            From residential rooftops to sprawling industrial complexes, we deliver certified Tier-1 engineering, turnkey DISCOM approvals, and 5-year free onsite maintenance.
          </p>
        </div>

        {/* Benefits Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {benefits.map((benefit, idx) => {
            const Icon = benefit.icon;
            return (
              <div
                key={idx}
                className="group p-8 bg-slate-900/60 hover:bg-slate-800/80 backdrop-blur-xl rounded-2xl border border-white/10 hover:border-amber-400/40 hover:shadow-2xl hover:shadow-amber-500/10 hover:-translate-y-1 transition-all duration-300 text-white"
              >
                <div
                  className={`w-12 h-12 rounded-xl flex items-center justify-center text-xl mb-6 transition-transform group-hover:scale-110 ${benefit.iconColor}`}
                >
                  <Icon className="w-6 h-6" />
                </div>
                <h3 className="text-xl font-bold text-white mb-2 font-display group-hover:text-amber-400 transition-colors">
                  {benefit.title}
                </h3>
                <p className="text-sm text-slate-300 leading-relaxed">
                  {benefit.description}
                </p>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
