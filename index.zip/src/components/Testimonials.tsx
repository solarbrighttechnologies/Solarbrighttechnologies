import React from 'react';
import { Star, Quote, CheckCircle2 } from 'lucide-react';

export const Testimonials: React.FC = () => {
  const reviews = [
    {
      name: 'Rajesh Sharma',
      role: 'Homeowner, Sector 14',
      system: '4 kW On-Grid Rooftop',
      savings: '₹6,200/mo saved',
      comment:
        'Our monthly electricity bill was averaging ₹6,500. After installing Solar Bright’s 4kW rooftop system, our recent bill was just ₹240! The team even handled the PM Surya Ghar subsidy application from start to finish.',
      avatarInitials: 'RS',
      avatarColor: 'bg-amber-100 text-amber-800',
    },
    {
      name: 'Anil Patel',
      role: 'MD, Patel Plastics Ltd',
      system: '40 kW Commercial Plant',
      savings: '₹48,000/mo saved',
      comment:
        'We commissioned a 40kW commercial plant on our production facility roof. The structural fabrication is top notch and passed our strict safety audit. We are saving over ₹48,000 every single month with zero breakdown.',
      avatarInitials: 'AP',
      avatarColor: 'bg-blue-100 text-blue-800',
    },
    {
      name: 'Virender Singh',
      role: 'Progressive Agro Farmer',
      system: '7.5 HP Solar Pump',
      savings: 'Zero diesel expenses',
      comment:
        'The solar submersible water pump has transformed our farm. No more waiting for erratic midnight 3-phase electricity or pouring money into diesel pumps. Water flows cleanly every sunny day directly to our canal.',
      avatarInitials: 'VS',
      avatarColor: 'bg-emerald-100 text-emerald-800',
    },
  ];

  return (
    <section id="testimonials" className="py-20 bg-slate-900/40 backdrop-blur-xl border-y border-white/10 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-xs font-bold uppercase tracking-widest text-amber-400">
            Real Customer Stories
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white mt-2 font-display">
            Trusted by Homes and Businesses in Bikaner
          </h2>
          <p className="text-base text-slate-300 mt-4 leading-relaxed">
            See how Solar Bright Technologies helped residential homeowners, business managers, and farmers eliminate high electricity tariffs.
          </p>
        </div>

        {/* Testimonials 3-Card Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {reviews.map((review, i) => (
            <div
              key={i}
              className="bg-slate-900/60 hover:bg-slate-800/80 backdrop-blur-xl p-8 rounded-2xl border border-white/10 hover:border-amber-400/40 shadow-xl transition-all duration-300 flex flex-col justify-between relative group text-white"
            >
              <div className="space-y-4">
                {/* Rating stars & Quote Icon */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1 text-amber-400">
                    {[...Array(5)].map((_, idx) => (
                      <Star key={idx} className="w-4 h-4 fill-amber-400 text-amber-400" />
                    ))}
                  </div>
                  <Quote className="w-6 h-6 text-slate-600 group-hover:text-amber-400 transition-colors" />
                </div>

                <p className="text-sm text-slate-300 italic leading-relaxed">
                  "{review.comment}"
                </p>
              </div>

              {/* Reviewer Bio */}
              <div className="mt-8 pt-6 border-t border-white/10 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div
                    className={`w-11 h-11 rounded-full font-bold flex items-center justify-center text-sm ${review.avatarColor}`}
                  >
                    {review.avatarInitials}
                  </div>
                  <div>
                    <p className="text-sm font-bold text-white flex items-center gap-1.5">
                      <span>{review.name}</span>
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    </p>
                    <p className="text-xs text-slate-400">{review.role}</p>
                  </div>
                </div>

                <div className="text-right">
                  <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded block">
                    {review.savings}
                  </span>
                  <span className="text-[10px] text-slate-400 mt-0.5 block">
                    {review.system}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
