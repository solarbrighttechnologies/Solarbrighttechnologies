import QRCode from 'qrcode';
import fs from 'fs';
import path from 'path';

async function generateQRCodes() {
  const instagramUrl = 'https://www.instagram.com/solarbrighttechnologies/';
  // Google Business Profile / Maps Search for Solar Bright Technologies Bikaner
  const googleProfileUrl = 'https://www.google.com/search?q=Solar+Bright+Technologies+Bikaner+Mukta+Prasad+Colony';

  const publicDir = path.resolve('./public');
  if (!fs.existsSync(publicDir)) {
    fs.mkdirSync(publicDir, { recursive: true });
  }

  // 1. Instagram QR Code
  await QRCode.toFile(path.join(publicDir, 'solarbrighttechnologies_qr.png'), instagramUrl, {
    errorCorrectionLevel: 'H',
    type: 'png',
    margin: 2,
    color: {
      dark: '#000000',
      light: '#ffffff',
    },
    width: 600,
  });

  const instaQrSvg = await QRCode.toString(instagramUrl, {
    errorCorrectionLevel: 'H',
    type: 'svg',
    margin: 2,
    color: {
      dark: '#000000',
      light: '#ffffff',
    },
    width: 600,
  });
  fs.writeFileSync(path.join(publicDir, 'solarbrighttechnologies_qr.svg'), instaQrSvg);

  // 2. Google Business Profile QR Code
  await QRCode.toFile(path.join(publicDir, 'google_profile_qr.png'), googleProfileUrl, {
    errorCorrectionLevel: 'H',
    type: 'png',
    margin: 2,
    color: {
      dark: '#1a73e8', // Google Blue
      light: '#ffffff',
    },
    width: 600,
  });

  const googleQrSvg = await QRCode.toString(googleProfileUrl, {
    errorCorrectionLevel: 'H',
    type: 'svg',
    margin: 2,
    color: {
      dark: '#1a73e8',
      light: '#ffffff',
    },
    width: 600,
  });
  fs.writeFileSync(path.join(publicDir, 'google_profile_qr.svg'), googleQrSvg);

  console.log('Successfully generated Instagram and Google Profile QR codes in public directory.');
}

generateQRCodes().catch(console.error);
